import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// Initialize GoogleGenAI with server-side API key
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build'
    }
  }
});

const HEALIO_SYSTEM_INSTRUCTION = `You are Healio, an experienced, compassionate, and wise adult-student mental health counselor at "A Gentle Place".
Your goal is to provide fast, crystal-clear, and deeply comforting guidance for individuals facing academic burnout, workplace exhaustion, anxiety, or tough decisions.

Tone & Style:
- Warm, grounded, serene, and empathetic—like a kind mentor in a sunlit sanctuary room.
- Avoid vague cliches or long walls of text. Provide immediate clarity and relief.

Always structure your responses into these 3 concise sections:
1. **Grounded Solace**: 1-2 empathetic sentences acknowledging their exact emotional weight and normalizing their experience without toxic positivity.
2. **Clear Decision Framework**: Break down their situation or choice into 2-3 distinct, actionable paths or perspectives. Clearly explain the tradeoff for each so they can see past the overwhelm.
3. **One Immediate Micro-Step & Gentle Question**: Give exactly 1 small, low-effort action they can take right now to breathe easier, followed by 1 caring, focused question to help them reflect.

Crisis Protocol: If acute crisis, self-harm, or despair is indicated, gently remind them they are not alone and share the 988 Suicide & Crisis Lifeline (call/text 988).`;

// Healio AI Counselor Endpoint (optimized for low latency and high clarity)
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const { messages } = req.body;

    if (!messages || !Array.isArray(messages)) {
      res.status(400).json({ error: 'Invalid messages format' });
      return;
    }

    // Format conversation history for Gemini
    const contents = messages.map((m: { role: string; content: string }) => ({
      role: m.role === 'user' ? 'user' : 'model',
      parts: [{ text: m.content }]
    }));

    // If API key is available, call Gemini with ThinkingLevel.LOW for maximum speed and sharp focus
    if (process.env.GEMINI_API_KEY) {
      let replyText = '';
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents,
          config: {
            systemInstruction: HEALIO_SYSTEM_INSTRUCTION,
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
            temperature: 0.65,
          }
        });
        replyText = response.text || '';
      } catch (firstErr) {
        console.warn('Primary model busy, attempting low-latency fallback model...', firstErr);
        try {
          const response = await ai.models.generateContent({
            model: 'gemini-flash-latest',
            contents,
            config: {
              systemInstruction: HEALIO_SYSTEM_INSTRUCTION,
              temperature: 0.65,
            }
          });
          replyText = response.text || '';
        } catch (secondErr) {
          console.warn('Fallback model also busy:', secondErr);
        }
      }

      if (replyText) {
        res.json({ reply: replyText });
        return;
      }
    }

    // High quality empathetic fallback if API is unreachable
    const lastUserMessage = messages[messages.length - 1]?.content || '';
    res.json({
      reply: `**Grounded Solace**\nI hear the exhaustion behind your words. Carrying heavy demands while trying to stay afloat takes a profound toll, and it makes complete sense that you feel stretched thin.\n\n**Clear Decision Framework**\nWhen you're facing this, consider two compassionate pathways:\n• **Path A (The Pacing Choice):** Instead of trying to resolve everything at once, pause non-critical obligations for 48 hours to let your nervous system reset before deciding.\n• **Path B (The Simplification Choice):** Identify the single non-negotiable deadline today and let go of or delegate the secondary items without guilt.\n\n**One Immediate Micro-Step & Gentle Question**\nStep away from your screen or workspace for just 5 minutes, drink a glass of cool water, and take three long exhales.\n\nWhich of those two paths feels like it would give your heart the most immediate breathing room right now?`
    });
  } catch (err: unknown) {
    console.error('Error in Healio chat:', err);
    res.json({
      reply: "I am listening closely. Take a slow, quiet breath with me. What is the single most pressing feeling or decision on your mind right now?"
    });
  }
});

// Mount Vite middleware in development or serve static in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on port ${PORT}`);
  });
}

startServer();
