import { ArrowRight, Compass } from 'lucide-react';
import { PATHWAYS } from '../data/wellnessData';
import { PathwayItem } from '../types';

interface SelectedPathwaysProps {
  onSelectPathway: (pathway: PathwayItem) => void;
  onViewAllClick: () => void;
}

export default function SelectedPathways({ onSelectPathway, onViewAllClick }: SelectedPathwaysProps) {
  return (
    <section id="pillars" className="w-full py-16 sm:py-24 border-t border-[#0F373E]/10">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Section Header matching reference */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 lg:mb-16 gap-6">
          <div>
            <p className="text-xs uppercase tracking-[0.22em] text-[#366772] font-semibold mb-2">
              SELECTED PATHWAYS
            </p>
            <h2 className="font-serif-display text-4xl sm:text-5xl lg:text-6xl font-normal tracking-tight text-[#0D3840]">
              Crafted with Purpose
            </h2>
          </div>

          <div>
            <button
              onClick={onViewAllClick}
              className="group inline-flex items-center gap-2 text-xs uppercase tracking-[0.2em] font-semibold text-[#18535F] hover:text-[#092B32] transition-colors cursor-pointer"
            >
              <span>EXPLORE ALL MODULES</span>
              <ArrowRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-1" />
            </button>
          </div>
        </div>

        {/* 4 Cards Grid matching reference layout exactly */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-7">
          {PATHWAYS.map((item) => (
            <div
              key={item.id}
              onClick={() => onSelectPathway(item)}
              className="group cursor-pointer flex flex-col"
            >
              {/* Image Frame */}
              <div className="relative aspect-4/3 sm:aspect-square lg:aspect-4/3 w-full overflow-hidden rounded-sm bg-[#D5E5E9] shadow-xs group-hover:shadow-md transition-all duration-300">
                <img
                  src={item.image}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
                />
                <div className="absolute inset-0 bg-[#0E3A42]/10 group-hover:bg-[#0E3A42]/0 transition-colors duration-300" />
                
                {/* Floating subtle category indicator */}
                <div className="absolute top-2.5 right-2.5 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-[#EBF2F4]/90 backdrop-blur-xs px-2 py-1 rounded-xs text-[10px] uppercase tracking-wider text-[#0E3A42] font-medium flex items-center gap-1">
                  <Compass className="w-3 h-3 text-[#1B5B67]" />
                  <span>View Details</span>
                </div>
              </div>

              {/* Title & Subtitle Below Card matching reference image */}
              <div className="mt-4 text-center">
                <h3 className="text-xs sm:text-sm uppercase tracking-[0.16em] font-semibold text-[#0E3A42] group-hover:text-[#1F6775] transition-colors">
                  {item.title}
                </h3>
                <p className="mt-1 text-[11px] tracking-[0.18em] uppercase text-[#47747E] font-medium">
                  {item.category}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
