import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, Music, ChevronUp, ChevronDown } from 'lucide-react';
import { MusicTrack } from '../data/musicTracks';

interface GlobalMusicBarProps {
  currentTrack: MusicTrack;
  isPlaying: boolean;
  isMuted: boolean;
  autoplayBlocked: boolean;
  onTogglePlay: () => void;
  onToggleMute: () => void;
  onNext: () => void;
  onPrev: () => void;
  onOpenSanctuary: () => void;
  onUnblockAutoplay: () => void;
}

export default function GlobalMusicBar({
  currentTrack,
  isPlaying,
  isMuted,
  autoplayBlocked,
  onTogglePlay,
  onToggleMute,
  onNext,
  onPrev,
  onOpenSanctuary,
  onUnblockAutoplay
}: GlobalMusicBarProps) {
  return (
    <>
      {/* Autoplay prompt banner if browser blocked initial unmuted autoplay */}
      {autoplayBlocked && (
        <div
          onClick={onUnblockAutoplay}
          className="fixed top-18 left-1/2 -translate-x-1/2 z-50 bg-[#0C323A]/95 backdrop-blur-md text-[#FAF3EB] px-5 py-2.5 rounded-full shadow-2xl border border-white/20 flex items-center gap-3 cursor-pointer hover:bg-[#07242A] transition-transform hover:scale-102 animate-bounce"
        >
          <span className="w-2.5 h-2.5 rounded-full bg-[#8CD7E5] animate-ping"></span>
          <span className="text-xs font-medium">
            Click anywhere or tap here to begin calming sanctuary music
          </span>
          <span className="bg-[#8CD7E5] text-[#0A262C] text-[10px] uppercase font-bold px-2 py-0.5 rounded-full">
            Play
          </span>
        </div>
      )}

      {/* Floating Bottom Music Sanctuary Bar */}
      <div className="fixed bottom-4 left-4 right-4 sm:left-auto sm:right-6 sm:max-w-md z-40 bg-[#0A262C]/95 backdrop-blur-md text-white rounded-full shadow-2xl border border-white/15 px-4 py-2.5 flex items-center justify-between gap-3 transition-all">
        {/* Track Info with Animated Wave */}
        <div
          onClick={onOpenSanctuary}
          className="flex items-center gap-3 min-w-0 cursor-pointer group flex-1"
          title="Click to view Calming Music Sanctuary"
        >
          <div className="w-8 h-8 rounded-full bg-[#144752] group-hover:bg-[#1D5E6C] flex items-center justify-center shrink-0 border border-white/10 transition-colors">
            {isPlaying ? (
              <div className="flex items-end gap-0.5 h-3.5">
                <span className="w-0.5 h-full bg-[#8CD7E5] animate-pulse"></span>
                <span className="w-0.5 h-2 bg-[#8CD7E5] animate-pulse delay-75"></span>
                <span className="w-0.5 h-3 bg-[#8CD7E5] animate-pulse delay-150"></span>
              </div>
            ) : (
              <Music className="w-3.5 h-3.5 text-[#8CD7E5]" />
            )}
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="text-[9px] uppercase tracking-widest text-[#8CD7E5] font-semibold">
                {isPlaying ? 'PLAYING' : 'PAUSED'}
              </span>
              <span className="text-[10px] text-white/50">·</span>
              <span className="text-[10px] text-[#D2E7EC] truncate">
                {currentTrack.badge}
              </span>
            </div>
            <p className="text-xs font-medium text-white truncate group-hover:text-[#8CD7E5] transition-colors">
              {currentTrack.title}
            </p>
          </div>
        </div>

        {/* Playback Controls */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          <button
            onClick={onPrev}
            className="p-1.5 text-white/70 hover:text-white rounded-full hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Previous calming track"
          >
            <SkipBack className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={onTogglePlay}
            className="p-2 bg-[#FAF3EB] text-[#0A262C] hover:bg-white rounded-full shadow-xs transition-transform hover:scale-105 cursor-pointer"
            aria-label={isPlaying ? 'Pause music' : 'Play music'}
          >
            {isPlaying ? (
              <Pause className="w-3.5 h-3.5 fill-[#0A262C]" />
            ) : (
              <Play className="w-3.5 h-3.5 fill-[#0A262C] ml-0.5" />
            )}
          </button>

          <button
            onClick={onNext}
            className="p-1.5 text-white/70 hover:text-white rounded-full hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Next calming track"
          >
            <SkipForward className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={onToggleMute}
            className="p-1.5 text-white/70 hover:text-white rounded-full hover:bg-white/10 transition-colors cursor-pointer"
            aria-label={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? (
              <VolumeX className="w-3.5 h-3.5 text-amber-300" />
            ) : (
              <Volume2 className="w-3.5 h-3.5" />
            )}
          </button>
        </div>
      </div>
    </>
  );
}
