import { useState, useEffect, useRef } from 'react';
import { X, Volume2, VolumeX, Sparkles, RotateCcw } from 'lucide-react';

interface BreathingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function BreathingModal({ isOpen, onClose }: BreathingModalProps) {
  const [phase, setPhase] = useState<'Inhale' | 'Hold' | 'Exhale'>('Inhale');
  const [countdown, setCountdown] = useState(4);
  const [cycles, setCycles] = useState(0);
  const [soundEnabled, setSoundEnabled] = useState(true);

  const audioCtxRef = useRef<AudioContext | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);

  useEffect(() => {
    if (!isOpen) return;

    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev > 1) return prev - 1;

        if (phase === 'Inhale') {
          setPhase('Hold');
          return 7;
        } else if (phase === 'Hold') {
          setPhase('Exhale');
          return 8;
        } else {
          setPhase('Inhale');
          setCycles((c) => c + 1);
          return 4;
        }
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isOpen, phase]);

  // Audio ocean sound synthesize
  useEffect(() => {
    if (!isOpen || !soundEnabled) {
      if (gainNodeRef.current) {
        gainNodeRef.current.gain.setValueAtTime(0, audioCtxRef.current?.currentTime || 0);
      }
      return;
    }

    try {
      if (!audioCtxRef.current) {
        const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        audioCtxRef.current = new AudioContextClass();
      }

      if (audioCtxRef.current.state === 'suspended') {
        audioCtxRef.current.resume();
      }

      if (!gainNodeRef.current) {
        const bufferSize = audioCtxRef.current.sampleRate * 2;
        const noiseBuffer = audioCtxRef.current.createBuffer(1, bufferSize, audioCtxRef.current.sampleRate);
        const output = noiseBuffer.getChannelData(0);
        let b0 = 0, b1 = 0, b2 = 0;
        for (let i = 0; i < bufferSize; i++) {
          const white = Math.random() * 2 - 1;
          b0 = 0.99886 * b0 + white * 0.0555179;
          b1 = 0.99332 * b1 + white * 0.0750759;
          b2 = 0.96900 * b2 + white * 0.1538520;
          output[i] = (b0 + b1 + b2) * 0.07;
        }

        const whiteNoise = audioCtxRef.current.createBufferSource();
        whiteNoise.buffer = noiseBuffer;
        whiteNoise.loop = true;

        const filter = audioCtxRef.current.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.value = 350;

        const gainNode = audioCtxRef.current.createGain();
        gainNode.gain.setValueAtTime(0.05, audioCtxRef.current.currentTime);

        whiteNoise.connect(filter);
        filter.connect(gainNode);
        gainNode.connect(audioCtxRef.current.destination);
        whiteNoise.start(0);

        gainNodeRef.current = gainNode;
      } else {
        gainNodeRef.current.gain.setValueAtTime(0.05, audioCtxRef.current.currentTime);
      }
    } catch {
      // Audio fallback
    }
  }, [isOpen, soundEnabled]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#08282F]/85 backdrop-blur-md">
      <div className="relative w-full max-w-lg bg-[#EBF2F4] rounded-sm p-8 text-center shadow-2xl border border-[#0F373E]/20">
        {/* Controls Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#0F373E]/10">
          <div className="flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-[#0E3A42]">
            <Sparkles className="w-4 h-4 text-[#1B6E7D]" />
            <span>Somatic Nervous System Reset</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="p-1.5 rounded-sm hover:bg-[#D8E7EB] text-[#0E3A42] transition-colors"
              title={soundEnabled ? 'Mute sound' : 'Unmute ocean sound'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-700" /> : <VolumeX className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-sm hover:bg-[#D8E7EB] text-[#0E3A42] transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Breathing Animation */}
        <div className="py-12 flex flex-col items-center justify-center min-h-[300px]">
          <div
            className={`w-52 h-52 rounded-full border-2 border-[#1E6B7A]/40 flex items-center justify-center transition-all duration-1000 ${
              phase === 'Inhale'
                ? 'scale-115 bg-[#C9E4EA]/60 border-[#1E6B7A]'
                : phase === 'Hold'
                ? 'scale-115 bg-[#B8DBE2]/80 border-[#165662]'
                : 'scale-90 bg-[#DCEBF0]/40'
            }`}
          >
            <div
              className={`w-36 h-36 rounded-full flex flex-col items-center justify-center shadow-inner transition-all duration-700 ${
                phase === 'Inhale'
                  ? 'bg-[#98C7D2] scale-105'
                  : phase === 'Hold'
                  ? 'bg-[#82B5C1] scale-100'
                  : 'bg-[#B0D3DC] scale-95'
              }`}
            >
              <span className="text-xs uppercase tracking-[0.2em] font-bold text-[#0A2E35]">
                {phase}
              </span>
              <span className="font-serif-display text-4xl font-bold text-[#0A2E35] tabular-nums mt-1">
                {countdown}s
              </span>
            </div>
          </div>

          <p className="mt-8 text-sm text-[#1B4B54] font-medium max-w-xs">
            {phase === 'Inhale' && 'Slowly fill your lungs with fresh ocean calm through your nose...'}
            {phase === 'Hold' && 'Gently hold this space. Let tension dissolve from your shoulders...'}
            {phase === 'Exhale' && 'Release slowly through parted lips. Unclench your jaw and let go...'}
          </p>
        </div>

        {/* Footer info */}
        <div className="pt-4 border-t border-[#0F373E]/10 flex items-center justify-between text-xs text-[#3E666F]">
          <span className="tabular-nums">Cycles Completed: <strong className="text-[#0E3A42]">{cycles}</strong></span>
          <button
            onClick={() => {
              setPhase('Inhale');
              setCountdown(4);
              setCycles(0);
            }}
            className="flex items-center gap-1.5 text-xs text-[#165662] hover:underline cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restart</span>
          </button>
        </div>
      </div>
    </div>
  );
}
