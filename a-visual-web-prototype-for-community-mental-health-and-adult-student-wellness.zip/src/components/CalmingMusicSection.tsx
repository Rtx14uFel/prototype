import { useState, useRef, useEffect } from 'react';
import { Play, Pause, Clock, Music2, Waves, ExternalLink, Sparkles } from 'lucide-react';
import { CALMING_TRACKS } from '../data/musicTracks';

interface CalmingMusicSectionProps {
  activeTrackIndex: number;
  onSelectTrack: (index: number) => void;
  isPlaying: boolean;
  isMuted: boolean;
  onTogglePlay: () => void;
}

export default function CalmingMusicSection({
  activeTrackIndex,
  onSelectTrack,
  isPlaying,
  isMuted,
  onTogglePlay
}: CalmingMusicSectionProps) {
  const [isOceanSoundOn, setIsOceanSoundOn] = useState(false);
  const [timerMinutes, setTimerMinutes] = useState<number | null>(null);
  const [timerSecondsLeft, setTimerSecondsLeft] = useState<number>(0);
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'piano' | 'lofi' | 'acoustic' | 'ambient' | 'sleep'>('all');

  const activeTrack = CALMING_TRACKS[activeTrackIndex] || CALMING_TRACKS[0];

  // Web Audio synth for layering natural ocean noise
  const audioCtxRef = useRef<AudioContext | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);

  // Relaxation timer countdown
  useEffect(() => {
    if (!timerMinutes) return;

    setTimerSecondsLeft(timerMinutes * 60);
    const interval = setInterval(() => {
      setTimerSecondsLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setTimerMinutes(null);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [timerMinutes]);

  // Audio synthesizer for soothing surf
  useEffect(() => {
    if (!isOceanSoundOn) {
      if (gainNodeRef.current) {
        gainNodeRef.current.gain.setValueAtTime(0, audioCtxRef.current?.currentTime || 0);
      }
      return;
    }

    try {
      if (!audioCtxRef.current) {
        const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        audioCtxRef.current = new AudioContextClass();
      }

      if (audioCtxRef.current.state === 'suspended') {
        audioCtxRef.current.resume();
      }

      if (!gainNodeRef.current) {
        const bufferSize = audioCtxRef.current.sampleRate * 2;
        const noiseBuffer = audioCtxRef.current.createBuffer(1, bufferSize, audioCtxRef.current.sampleRate);
        const output = noiseBuffer.getChannelData(0);
        let b0 = 0, b1 = 0, b2 = 0;
        for (let i = 0; i < bufferSize; i++) {
          const white = Math.random() * 2 - 1;
          b0 = 0.99886 * b0 + white * 0.0555179;
          b1 = 0.99332 * b1 + white * 0.0750759;
          b2 = 0.96900 * b2 + white * 0.1538520;
          output[i] = (b0 + b1 + b2) * 0.07;
        }

        const whiteNoise = audioCtxRef.current.createBufferSource();
        whiteNoise.buffer = noiseBuffer;
        whiteNoise.loop = true;

        const filter = audioCtxRef.current.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.value = 340;

        const gainNode = audioCtxRef.current.createGain();
        gainNode.gain.setValueAtTime(0.05, audioCtxRef.current.currentTime);

        whiteNoise.connect(filter);
        filter.connect(gainNode);
        gainNode.connect(audioCtxRef.current.destination);
        whiteNoise.start(0);

        gainNodeRef.current = gainNode;
      } else {
        gainNodeRef.current.gain.setValueAtTime(0.05, audioCtxRef.current.currentTime);
      }
    } catch {
      // Audio fallback
    }
  }, [isOceanSoundOn]);

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const filteredTracks = CALMING_TRACKS.filter((track) => {
    if (categoryFilter === 'all') return true;
    if (categoryFilter === 'piano') return track.badge.toLowerCase().includes('piano');
    if (categoryFilter === 'lofi') return track.badge.toLowerCase().includes('lofi');
    if (categoryFilter === 'acoustic') return track.badge.toLowerCase().includes('acoustic');
    if (categoryFilter === 'ambient') return track.badge.toLowerCase().includes('ambient') || track.badge.toLowerCase().includes('celestial');
    if (categoryFilter === 'sleep') return track.badge.toLowerCase().includes('sleep') || track.badge.toLowerCase().includes('rest');
    return true;
  });

  return (
    <section id="calming-music" className="w-full py-16 sm:py-24 border-t border-[#0F373E]/10 bg-[#E3EDEF]/70 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2 h-2 rounded-full bg-[#1F7B8C] animate-pulse"></span>
              <p className="text-xs uppercase tracking-[0.24em] text-[#366772] font-semibold">
                CALMING MUSIC SANCTUARY
              </p>
            </div>
            <h2 className="font-serif-display text-4xl sm:text-5xl font-normal tracking-tight text-[#0D3840]">
              Restorative Sounds & Melodies
            </h2>
            <p className="text-sm sm:text-base text-[#254C54] font-light mt-2 max-w-2xl leading-relaxed">
              Immediate calming music designed for adult learners, night study, soothing overstimulation, and deep restorative sleep. Synchronized with the player controls.
            </p>
          </div>

          {/* Sound Controls & Timer Pill */}
          <div className="flex flex-wrap items-center gap-3">
            {/* Ocean Surf Layering Toggle */}
            <button
              onClick={() => setIsOceanSoundOn(!isOceanSoundOn)}
              className={`text-xs px-3.5 py-2 rounded-xs border flex items-center gap-2 transition-all cursor-pointer ${
                isOceanSoundOn
                  ? 'bg-[#0E3A42] text-white border-[#0E3A42] shadow-2xs'
                  : 'bg-white/80 text-[#1C4E57] border-[#0F373E]/15 hover:bg-white'
              }`}
              title="Layer soft ambient ocean surf waves with the music"
            >
              <Waves className="w-3.5 h-3.5" />
              <span>{isOceanSoundOn ? 'Ocean Surf: ON' : 'Add Ocean Surf'}</span>
            </button>

            {/* Relaxation Timer */}
            <div className="flex items-center bg-white/80 border border-[#0F373E]/15 rounded-xs p-1 text-xs text-[#1C4E57]">
              <Clock className="w-3.5 h-3.5 ml-2 mr-1 text-[#225761]" />
              <span className="text-[11px] mr-2">
                {timerMinutes ? formatTimer(timerSecondsLeft) : 'Timer:'}
              </span>
              {[15, 30, 60].map((mins) => (
                <button
                  key={mins}
                  onClick={() => setTimerMinutes(timerMinutes === mins ? null : mins)}
                  className={`px-2 py-1 text-[10px] rounded-xs font-medium cursor-pointer transition-colors ${
                    timerMinutes === mins
                      ? 'bg-[#0E3A42] text-white'
                      : 'hover:bg-[#DEE9EC] text-[#204F58]'
                  }`}
                >
                  {mins}m
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 mb-8">
          <span className="text-xs uppercase tracking-wider text-[#355E67] font-semibold mr-1">
            Category:
          </span>
          {[
            { id: 'all', label: 'All 9 Tracks' },
            { id: 'piano', label: 'Peaceful Piano' },
            { id: 'lofi', label: 'Chill Lofi' },
            { id: 'acoustic', label: 'Acoustic Guitar' },
            { id: 'ambient', label: 'Ambient & Waves' },
            { id: 'sleep', label: 'Sleep & Rest' }
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setCategoryFilter(cat.id as typeof categoryFilter)}
              className={`text-xs px-3 py-1.5 rounded-full transition-all cursor-pointer ${
                categoryFilter === cat.id
                  ? 'bg-[#0E3A42] text-white font-medium shadow-2xs'
                  : 'bg-white/80 text-[#214D56] hover:bg-white border border-[#0F373E]/10'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Main Music Showcase Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Main Video & Embedded Player */}
          <div className="lg:col-span-7 bg-[#0C323A] rounded-sm p-4 sm:p-5 shadow-xl border border-white/10 text-white">
            {/* Player Container with Official YouTube IFrame API Hooks for 100% pause/play sync */}
            <div className="relative aspect-16/9 w-full bg-black rounded-xs overflow-hidden shadow-inner">
              <iframe
                id="calming-youtube-player"
                key={activeTrack.youtubeId}
                src={`https://www.youtube-nocookie.com/embed/${activeTrack.youtubeId}?enablejsapi=1&autoplay=1&mute=${isMuted ? 1 : 0}&playsinline=1&rel=0`}
                title={activeTrack.title}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
                onLoad={() => {
                  // Subscribe iframe to postMessage bridge
                  const iframe = document.getElementById('calming-youtube-player') as HTMLIFrameElement | null;
                  if (iframe && iframe.contentWindow) {
                    iframe.contentWindow.postMessage(JSON.stringify({ event: 'listening' }), '*');
                  }
                }}
                className="w-full h-full border-0"
              />
            </div>

            {/* Now Playing Bar */}
            <div className="mt-4 pt-3 border-t border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase tracking-widest font-semibold px-2 py-0.5 bg-[#1B5763] text-[#D7EFF4] rounded-xs flex items-center gap-1.5">
                    <span className={`w-1.5 h-1.5 rounded-full ${isPlaying ? 'bg-[#8CD7E5] animate-ping' : 'bg-white/40'}`}></span>
                    {isPlaying ? 'NOW PLAYING' : 'PAUSED'}
                  </span>
                  <span className="text-xs text-[#9CCAD3]">
                    {activeTrack.artist}
                  </span>
                </div>
                <h3 className="font-serif-display text-xl sm:text-2xl text-white font-medium mt-1">
                  {activeTrack.title}
                </h3>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={onTogglePlay}
                  className="bg-white/15 hover:bg-white/25 text-white text-xs font-medium px-4 py-2 rounded-xs flex items-center gap-2 transition-colors cursor-pointer shadow-xs"
                >
                  {isPlaying ? (
                    <>
                      <Pause className="w-3.5 h-3.5 fill-white" />
                      <span>Pause Video</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5 fill-white" />
                      <span>Play Video</span>
                    </>
                  )}
                </button>

                <a
                  href={`https://youtu.be/${activeTrack.youtubeId}`}
                  target="_blank"
                  rel="noreferrer"
                  className="text-[11px] text-[#A2CED6] hover:text-white flex items-center gap-1.5 transition-colors"
                >
                  <span>YouTube</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>

            {/* Track Info Box */}
            <div className="mt-4 p-3 bg-[#113E47] rounded-xs text-xs text-[#C6E6EC] space-y-1 font-light leading-relaxed">
              <p>{activeTrack.description}</p>
              <p className="text-[11px] text-[#86BAC4]">
                <strong className="font-medium text-[#C6E6EC]">Recommended for:</strong> {activeTrack.idealFor}
              </p>
            </div>
          </div>

          {/* Playlist & Track Selection Column (All 9 tracks) */}
          <div className="lg:col-span-5 space-y-3">
            <div className="flex items-center justify-between pb-1">
              <h3 className="text-xs uppercase tracking-[0.2em] font-bold text-[#0D3840] flex items-center gap-2">
                <Music2 className="w-4 h-4 text-[#1C5D6B]" />
                <span>Sanctuary Playlist ({filteredTracks.length})</span>
              </h3>
              <span className="text-[11px] text-[#3E6871]">Click any track to switch</span>
            </div>

            <div className="space-y-2.5 max-h-[560px] overflow-y-auto pr-1">
              {filteredTracks.map((track) => {
                const globalIndex = CALMING_TRACKS.findIndex((t) => t.id === track.id);
                const isSelected = activeTrackIndex === globalIndex;

                return (
                  <div
                    key={track.id}
                    onClick={() => onSelectTrack(globalIndex)}
                    className={`p-3.5 rounded-sm border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-white border-[#0E3A42] shadow-md ring-1 ring-[#0E3A42]'
                        : 'bg-white/70 border-[#0F373E]/10 hover:bg-white hover:border-[#0F373E]/30'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3 mb-1.5">
                      <div className="flex items-center gap-2.5">
                        <div
                          className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 transition-colors ${
                            isSelected
                              ? 'bg-[#0E3A42] text-white'
                              : 'bg-[#DDEAEF] text-[#134954]'
                          }`}
                        >
                          {isSelected && isPlaying ? (
                            <div className="flex items-end gap-0.5 h-3">
                              <span className="w-0.5 h-full bg-white animate-pulse"></span>
                              <span className="w-0.5 h-2 bg-white animate-pulse delay-75"></span>
                              <span className="w-0.5 h-2.5 bg-white animate-pulse delay-150"></span>
                            </div>
                          ) : (
                            <Play className="w-3 h-3 fill-[#134954] text-[#134954] ml-0.5" />
                          )}
                        </div>

                        <div>
                          <h4 className="text-xs sm:text-sm font-semibold text-[#0D3840]">
                            {track.title}
                          </h4>
                          <span className="text-[10px] text-[#416870]">
                            {track.artist}
                          </span>
                        </div>
                      </div>

                      <span
                        className={`text-[9px] uppercase tracking-wider font-semibold px-2 py-0.5 rounded-xs shrink-0 ${
                          isSelected
                            ? 'bg-[#0E3A42] text-white'
                            : 'bg-[#E1EDF0] text-[#164E59]'
                        }`}
                      >
                        {track.badge}
                      </span>
                    </div>

                    <p className="text-[11px] text-[#2A515A] font-light leading-relaxed pl-9">
                      {track.description}
                    </p>
                  </div>
                );
              })}
            </div>

            {/* Listening Practice Card */}
            <div className="p-3.5 bg-white/80 rounded-sm border border-[#0F373E]/10 mt-3">
              <div className="flex items-center gap-2 text-xs font-semibold text-[#0E3A42] mb-1">
                <Sparkles className="w-3.5 h-3.5 text-[#1B6673]" />
                <span>Synchronized Audio Controls</span>
              </div>
              <p className="text-[11px] text-[#315760] font-light leading-relaxed">
                The play and pause controls directly control the embedded video and audio. You can also pause or skip tracks using the floating bar at the bottom.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
