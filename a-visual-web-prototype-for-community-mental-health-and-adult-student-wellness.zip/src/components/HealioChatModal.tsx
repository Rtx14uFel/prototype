import { useState, useRef, useEffect } from 'react';
import { Send, X, RefreshCw, Shield, HelpCircle, ArrowRight, Sparkles } from 'lucide-react';

interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: string;
}

interface HealioChatModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const HEALIO_AVATAR = "/src/assets/images/healio_counselor_portrait_1790580704967.jpg";

const QUICK_PROMPTS = [
  "I'm overwhelmed balancing work, family, and study.",
  "I'm stuck on a hard decision and don't know what to do.",
  "I feel burnt out and can't find motivation today.",
  "I feel guilty whenever I try to rest."
];

// Helper to format Healio's markdown responses cleanly
function FormattedMessage({ text }: { text: string }) {
  const paragraphs = text.split('\n\n');

  return (
    <div className="space-y-3">
      {paragraphs.map((para, i) => {
        // Section headers with bold
        if (para.startsWith('**') && para.includes('**\n')) {
          const [header, ...rest] = para.split('\n');
          const cleanHeader = header.replace(/\*\*/g, '');
          const body = rest.join('\n');
          return (
            <div key={i} className="space-y-1">
              <h5 className="font-semibold text-[#0E3A42] tracking-wide text-[13px] border-b border-[#0F373E]/10 pb-0.5">
                {cleanHeader}
              </h5>
              <div className="whitespace-pre-wrap text-[#1E454E] leading-relaxed">
                {body}
              </div>
            </div>
          );
        }

        // Bullet point lists
        if (para.includes('• ') || para.includes('- ')) {
          const lines = para.split('\n');
          return (
            <div key={i} className="space-y-1.5 my-1">
              {lines.map((line, lIdx) => {
                if (line.trim().startsWith('•') || line.trim().startsWith('-')) {
                  const cleaned = line.replace(/^[•\-]\s*/, '');
                  return (
                    <div key={lIdx} className="flex items-start gap-2 pl-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#1F6B79] mt-1.5 shrink-0" />
                      <span className="whitespace-pre-wrap text-[#1A424B] leading-relaxed">
                        {cleaned.split('**').map((part, pIdx) =>
                          pIdx % 2 === 1 ? <strong key={pIdx} className="font-semibold text-[#0B2C33]">{part}</strong> : part
                        )}
                      </span>
                    </div>
                  );
                }
                return (
                  <p key={lIdx} className="whitespace-pre-wrap text-[#1E454E] leading-relaxed">
                    {line}
                  </p>
                );
              })}
            </div>
          );
        }

        return (
          <p key={i} className="whitespace-pre-wrap leading-relaxed text-[#1E454E]">
            {para.split('**').map((part, pIdx) =>
              pIdx % 2 === 1 ? <strong key={pIdx} className="font-semibold text-[#0B2C33]">{part}</strong> : part
            )}
          </p>
        );
      })}
    </div>
  );
}

export default function HealioChatModal({ isOpen, onClose }: HealioChatModalProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-msg',
      role: 'model',
      content:
        "Hello, I'm Healio. Take a slow, quiet breath with me—you don't have to carry everything alone right now.\n\nWhether you are navigating study exhaustion, stuck at a stressful crossroads, or need a calm space to weigh your choices, I am right here.\n\nWhat is feeling most overwhelming or pressing on your mind today?",
      timestamp: 'Just now'
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLTextAreaElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
        scrollToBottom();
      }, 150);
    }
  }, [isOpen, messages]);

  if (!isOpen) return null;

  const handleSendMessage = async (textToSend?: string) => {
    const content = (textToSend || inputValue).trim();
    if (!content || isLoading) return;

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInputValue('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMessages.map((m) => ({
            role: m.role,
            content: m.content
          }))
        })
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();
      const modelMessage: ChatMessage = {
        id: `model-${Date.now()}`,
        role: 'model',
        content: data.reply || "I am listening closely. Please take your time, and tell me a bit more.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages((prev) => [...prev, modelMessage]);
    } catch {
      const fallbackMessage: ChatMessage = {
        id: `model-fallback-${Date.now()}`,
        role: 'model',
        content:
          "**Grounded Solace**\nI hear how much weight you are carrying right now. Let's take a slow breath together.\n\n**Clear Decision Framework**\nWhen you're facing this, consider two compassionate pathways:\n• **Path A (The Pacing Choice):** Pause secondary tasks for 48 hours to let your mind settle.\n• **Path B (The Simplification Choice):** Pick the single essential priority for today and release the rest.\n\n**One Immediate Micro-Step & Gentle Question**\nDrink a glass of water and take three deep exhales.\n\nWhich of those two paths gives you the most relief right now?",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, fallbackMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleResetChat = () => {
    setMessages([
      {
        id: `welcome-${Date.now()}`,
        role: 'model',
        content:
          "Welcome back. Take a deep, gentle breath with me. How can I support your thoughts or choices today?",
        timestamp: 'Just now'
      }
    ]);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/65 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="w-full max-w-2xl bg-[#F7FAFA] border border-[#0E3A42]/20 rounded-xl shadow-2xl flex flex-col overflow-hidden max-h-[92vh] sm:max-h-[86vh] h-[740px]"
        role="dialog"
        aria-modal="true"
      >
        {/* Header with Healio's Portrait Profile */}
        <div className="bg-[#0A2A30] text-white px-5 py-3.5 flex items-center justify-between border-b border-white/10 shrink-0">
          <div className="flex items-center gap-3.5">
            <div className="relative">
              <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-[#8CD7E5] shadow-md bg-[#163E46] shrink-0">
                <img
                  src={HEALIO_AVATAR}
                  alt="Healio, AI Counselor"
                  className="w-full h-full object-cover object-center"
                />
              </div>
              <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-400 border-2 border-[#0A2A30] shadow-xs"></span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-serif-display text-lg sm:text-xl font-medium text-white tracking-wide">
                  Healio
                </h3>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-[#185561] text-[#8CD7E5] border border-white/10">
                  AI Counselor
                </span>
              </div>
              <p className="text-[11px] text-[#A6D5DD] font-light">
                Compassionate listening · Fast decision frameworks · Grounded solace
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleResetChat}
              className="p-2 text-white/70 hover:text-white rounded-full hover:bg-white/10 transition-colors cursor-pointer"
              title="Reset conversation"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-white/70 hover:text-white rounded-full hover:bg-white/10 transition-colors cursor-pointer"
              aria-label="Close Healio Counselor"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Confidentiality Notice Banner */}
        <div className="bg-[#E2EFF2] px-5 py-2 border-b border-[#0E3A42]/10 flex items-center justify-between text-[11px] text-[#1D515B] shrink-0">
          <div className="flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5 text-[#2A6E7C]" />
            <span>Confidential Sanctuary Space · Fast & clear guidance</span>
          </div>
          <span className="hidden sm:inline text-[#3F6F79]">Non-judgmental Support</span>
        </div>

        {/* Message Thread */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {messages.map((message) => {
            const isUser = message.role === 'user';
            return (
              <div
                key={message.id}
                className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-9 h-9 rounded-full overflow-hidden border border-[#0E3A42]/20 shrink-0 mt-0.5 shadow-xs">
                    <img
                      src={HEALIO_AVATAR}
                      alt="Healio"
                      className="w-full h-full object-cover object-center"
                    />
                  </div>
                )}

                <div
                  className={`max-w-[86%] sm:max-w-[80%] rounded-xl p-4 text-xs sm:text-[13px] leading-relaxed shadow-sm ${
                    isUser
                      ? 'bg-[#0E3A42] text-[#FAF3EB] rounded-tr-none'
                      : 'bg-white border border-[#0F373E]/12 text-[#133A42] rounded-tl-none font-light'
                  }`}
                >
                  {isUser ? (
                    <div className="whitespace-pre-wrap">{message.content}</div>
                  ) : (
                    <FormattedMessage text={message.content} />
                  )}

                  <div
                    className={`mt-2.5 text-[10px] ${
                      isUser ? 'text-[#A0CBD4] text-right' : 'text-[#6C8E96]'
                    }`}
                  >
                    {message.timestamp}
                  </div>
                </div>
              </div>
            );
          })}

          {/* Thinking / Loading indicator */}
          {isLoading && (
            <div className="flex gap-3 justify-start">
              <div className="w-9 h-9 rounded-full overflow-hidden border border-[#0E3A42]/20 shrink-0 mt-0.5">
                <img
                  src={HEALIO_AVATAR}
                  alt="Healio"
                  className="w-full h-full object-cover object-center opacity-80"
                />
              </div>
              <div className="bg-white border border-[#0F373E]/12 rounded-xl p-3.5 text-xs text-[#204952] flex items-center gap-2 shadow-xs">
                <span className="w-1.5 h-1.5 rounded-full bg-[#185E6E] animate-bounce"></span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#185E6E] animate-bounce delay-100"></span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#185E6E] animate-bounce delay-200"></span>
                <span className="text-[11px] text-[#476F77] ml-1 font-medium">
                  Healio is reflecting...
                </span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Quick Prompt Starters */}
        {messages.length <= 2 && (
          <div className="px-4 py-2.5 bg-[#EEF5F7] border-t border-[#0F373E]/10 shrink-0">
            <p className="text-[10px] uppercase tracking-wider text-[#35616B] font-semibold mb-1.5 flex items-center gap-1">
              <HelpCircle className="w-3 h-3 text-[#216775]" />
              <span>Suggested Reflection Starters:</span>
            </p>
            <div className="flex flex-wrap gap-1.5">
              {QUICK_PROMPTS.map((prompt, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendMessage(prompt)}
                  className="text-[11px] bg-white hover:bg-[#DEEBF0] text-[#154650] border border-[#0F373E]/15 px-3 py-1.5 rounded-full transition-colors cursor-pointer text-left flex items-center gap-1 shadow-2xs hover:border-[#154650]/40"
                >
                  <span>{prompt}</span>
                  <ArrowRight className="w-2.5 h-2.5 shrink-0 opacity-60" />
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input Composer */}
        <div className="p-3.5 sm:p-4 bg-white border-t border-[#0F373E]/12 shrink-0">
          <div className="flex items-end gap-2 bg-[#F2F7F8] border border-[#0F373E]/15 rounded-lg p-2.5 focus-within:border-[#0E3A42] focus-within:ring-1 focus-within:ring-[#0E3A42] transition-all shadow-xs">
            <textarea
              ref={inputRef}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Tell Healio what decision or overwhelm is on your mind..."
              rows={2}
              className="flex-1 bg-transparent resize-none border-0 text-xs sm:text-sm text-[#0D3840] placeholder:text-[#678B93] focus:outline-hidden leading-relaxed"
            />

            <button
              onClick={() => handleSendMessage()}
              disabled={!inputValue.trim() || isLoading}
              className="p-2.5 rounded-md bg-[#0E3A42] text-white hover:bg-[#07252B] disabled:opacity-40 disabled:cursor-not-allowed transition-all cursor-pointer shadow-xs shrink-0"
              aria-label="Send message to Healio"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>

          <div className="mt-2 text-center text-[10px] text-[#698B93]">
            Healio offers compassionate counseling and decision clarity. If in crisis, call/text <strong>988</strong> (Lifeline).
          </div>
        </div>
      </div>
    </div>
  );
}
