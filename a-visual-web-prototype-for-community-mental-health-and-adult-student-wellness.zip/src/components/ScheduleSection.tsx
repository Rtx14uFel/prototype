import { useState } from 'react';
import { Calendar as CalendarIcon, Clock, MapPin, CheckCircle2, User, Mail, Phone, HeartHandshake, Shield, Sparkles } from 'lucide-react';

export default function ScheduleSection() {
  const serviceOptions = [
    {
      id: 'treatment',
      title: 'Treatment & Recovery',
      category: 'Treatment',
      icon: Sparkles,
      duration: '60 mins',
      description: 'Structured therapeutic care for acute academic burnout, somatic tension regulation, and customized restorative pacing.'
    },
    {
      id: 'counseling',
      title: 'Individual & Student Counseling',
      category: 'Counseling',
      icon: Shield,
      duration: '50 mins',
      description: 'One-on-one confidential counseling addressing academic stress, work-life balance, imposter feelings, and emotional well-being.'
    },
    {
      id: 'community-advocacy',
      title: 'Community Advocacy & Navigation',
      category: 'Community Advocacy',
      icon: HeartHandshake,
      duration: '45 mins',
      description: 'Support navigating adult-student accommodations, civic health resources, mutual aid networks, and educational advocacy.'
    }
  ];

  const availableSlots = [
    { id: 't1', time: '09:30 AM', period: 'Morning' },
    { id: 't2', time: '11:00 AM', period: 'Morning' },
    { id: 't3', time: '02:00 PM', period: 'Afternoon' },
    { id: 't4', time: '04:30 PM', period: 'Afternoon' },
    { id: 't5', time: '06:30 PM', period: 'Evening (Adult Students)' },
    { id: 't6', time: '08:00 PM', period: 'Evening (Night Scholars)' }
  ];

  const [selectedService, setSelectedService] = useState(serviceOptions[0].id);
  const [selectedDate, setSelectedDate] = useState('2026-09-29');
  const [selectedTime, setSelectedTime] = useState('06:30 PM');
  const [modality, setModality] = useState<'virtual' | 'in-person'>('virtual');
  
  const [bookingForm, setBookingForm] = useState({
    name: '',
    email: '',
    phone: '',
    notes: ''
  });

  const [isBooked, setIsBooked] = useState(false);
  const [loading, setLoading] = useState(false);

  const activeServiceObj = serviceOptions.find((s) => s.id === selectedService) || serviceOptions[0];

  const handleBooking = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setIsBooked(true);
    }, 600);
  };

  return (
    <section id="schedule" className="w-full py-16 sm:py-24 border-t border-[#0F373E]/10 bg-[#E8F1F3]/50">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <p className="text-xs uppercase tracking-[0.22em] text-[#366772] font-semibold mb-2">
            APPOINTMENTS & SESSIONS
          </p>
          <h2 className="font-serif-display text-4xl sm:text-5xl font-normal tracking-tight text-[#0D3840]">
            Schedule for Treatment, Counseling, & Community Advocacy
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#254C54] font-light leading-relaxed">
            Reserve your confidential session at A Gentle Place. Choose from dedicated treatment protocols, individual counseling, or community advocacy navigation.
          </p>
        </div>

        {isBooked ? (
          <div className="max-w-2xl mx-auto bg-white p-8 sm:p-10 rounded-sm border border-[#0F373E]/15 shadow-sm text-center">
            <div className="w-14 h-14 bg-emerald-100 text-emerald-800 rounded-full flex items-center justify-center mx-auto mb-5">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <h3 className="font-serif-display text-3xl text-[#0D3840] mb-2">
              Appointment Scheduled
            </h3>
            <p className="text-sm text-[#27535B] font-light mb-6">
              Thank you, <strong className="font-medium">{bookingForm.name || 'Friend'}</strong>. Your appointment has been reserved with A Gentle Place.
            </p>

            <div className="bg-[#EBF2F4] p-5 rounded-xs text-left text-xs sm:text-sm text-[#144752] space-y-2 mb-6 border border-[#0F373E]/10">
              <div className="flex justify-between border-b border-[#0F373E]/10 pb-2">
                <span className="text-[#416870]">Service:</span>
                <span className="font-medium text-[#0D3840]">{activeServiceObj.title}</span>
              </div>
              <div className="flex justify-between border-b border-[#0F373E]/10 pb-2">
                <span className="text-[#416870]">Date & Time:</span>
                <span className="font-medium text-[#0D3840]">{selectedDate} at {selectedTime}</span>
              </div>
              <div className="flex justify-between border-b border-[#0F373E]/10 pb-2">
                <span className="text-[#416870]">Modality:</span>
                <span className="font-medium text-[#0D3840] capitalize">{modality}</span>
              </div>
              <div className="flex justify-between pt-1">
                <span className="text-[#416870]">Confirmation sent to:</span>
                <span className="font-medium text-[#0D3840]">{bookingForm.email || 'gregoriorivera654@gmail.com'}</span>
              </div>
            </div>

            <div className="text-xs text-[#416870] mb-6">
              For any schedule adjustments or questions, contact us directly at <a href="mailto:gregoriorivera654@gmail.com" className="text-[#0D3840] font-medium underline">gregoriorivera654@gmail.com</a> or <a href="tel:09168623120" className="text-[#0D3840] font-medium underline">09168623120</a>.
            </div>

            <button
              onClick={() => setIsBooked(false)}
              className="bg-[#0E3A42] hover:bg-[#07242A] text-white text-xs uppercase tracking-widest font-medium px-6 py-3 rounded-xs transition-colors cursor-pointer"
            >
              Book Another Session
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Step 1: Select Service Category */}
            <div className="lg:col-span-5 space-y-4">
              <h3 className="text-xs uppercase tracking-[0.18em] font-bold text-[#0D3840] mb-2 flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-[#0E3A42] text-white text-[10px] flex items-center justify-center font-sans">1</span>
                Select Care Pathway
              </h3>

              <div className="space-y-3">
                {serviceOptions.map((service) => {
                  const Icon = service.icon;
                  const isSelected = selectedService === service.id;
                  return (
                    <div
                      key={service.id}
                      onClick={() => setSelectedService(service.id)}
                      className={`p-5 rounded-sm border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-white border-[#0E3A42] shadow-sm ring-1 ring-[#0E3A42]'
                          : 'bg-white/70 border-[#0F373E]/10 hover:bg-white hover:border-[#0F373E]/30'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3 mb-2">
                        <div className="flex items-center gap-2.5">
                          <div className={`p-2 rounded-xs ${isSelected ? 'bg-[#0E3A42] text-white' : 'bg-[#E1EDF0] text-[#14535F]'}`}>
                            <Icon className="w-4 h-4" />
                          </div>
                          <div>
                            <h4 className="text-sm font-semibold text-[#0D3840]">
                              {service.title}
                            </h4>
                            <span className="text-[11px] text-[#416870]">
                              {service.category} · {service.duration}
                            </span>
                          </div>
                        </div>
                      </div>
                      <p className="text-xs text-[#2A515A] font-light leading-relaxed">
                        {service.description}
                      </p>
                    </div>
                  );
                })}
              </div>

              {/* Modality Selector */}
              <div className="bg-white/80 p-5 rounded-sm border border-[#0F373E]/10">
                <span className="text-xs uppercase tracking-wider font-semibold text-[#0D3840] block mb-3">
                  Format / Modality
                </span>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setModality('virtual')}
                    className={`py-2.5 px-3 rounded-xs text-xs font-medium border flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                      modality === 'virtual'
                        ? 'bg-[#0E3A42] text-white border-[#0E3A42]'
                        : 'bg-[#EBF2F4] text-[#1E4D56] border-[#0F373E]/15 hover:bg-[#DDEAEF]'
                    }`}
                  >
                    <span>Virtual / Online Session</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setModality('in-person')}
                    className={`py-2.5 px-3 rounded-xs text-xs font-medium border flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                      modality === 'in-person'
                        ? 'bg-[#0E3A42] text-white border-[#0E3A42]'
                        : 'bg-[#EBF2F4] text-[#1E4D56] border-[#0F373E]/15 hover:bg-[#DDEAEF]'
                    }`}
                  >
                    <MapPin className="w-3.5 h-3.5" />
                    <span>In-Person Sanctuary</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Step 2 & 3: Date, Time & Contact Info */}
            <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-sm border border-[#0F373E]/10 shadow-xs">
              <form onSubmit={handleBooking} className="space-y-6">
                <div>
                  <h3 className="text-xs uppercase tracking-[0.18em] font-bold text-[#0D3840] mb-3 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#0E3A42] text-white text-[10px] flex items-center justify-center font-sans">2</span>
                    Select Preferred Date & Time
                  </h3>

                  {/* Date Input */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                    <div>
                      <label className="block text-xs font-medium text-[#204E57] mb-1.5 flex items-center gap-1.5">
                        <CalendarIcon className="w-3.5 h-3.5 text-[#185561]" />
                        <span>Date</span>
                      </label>
                      <input
                        type="date"
                        required
                        value={selectedDate}
                        onChange={(e) => setSelectedDate(e.target.value)}
                        className="w-full bg-[#F5F9FA] border border-[#0F373E]/20 rounded-xs px-3.5 py-2.5 text-xs text-[#0D3840] focus:outline-hidden focus:border-[#0E3A42]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-[#204E57] mb-1.5 flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-[#185561]" />
                        <span>Selected Time</span>
                      </label>
                      <input
                        type="text"
                        readOnly
                        value={selectedTime}
                        className="w-full bg-[#EBF2F4] border border-[#0F373E]/20 rounded-xs px-3.5 py-2.5 text-xs font-semibold text-[#0D3840] cursor-not-allowed"
                      />
                    </div>
                  </div>

                  {/* Time Slots */}
                  <div>
                    <label className="block text-xs text-[#416870] mb-2 font-medium">
                      Available Time Slots:
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {availableSlots.map((slot) => {
                        const isTimeSelected = selectedTime === slot.time;
                        return (
                          <button
                            key={slot.id}
                            type="button"
                            onClick={() => setSelectedTime(slot.time)}
                            className={`p-2 rounded-xs border text-left transition-colors cursor-pointer ${
                              isTimeSelected
                                ? 'bg-[#0E3A42] text-white border-[#0E3A42]'
                                : 'bg-[#F5F9FA] text-[#1C4D56] border-[#0F373E]/15 hover:bg-[#EBF2F4]'
                            }`}
                          >
                            <div className="text-xs font-semibold">{slot.time}</div>
                            <div className={`text-[10px] ${isTimeSelected ? 'text-white/80' : 'text-[#567E86]'}`}>
                              {slot.period}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Step 3: Client Details */}
                <div className="pt-5 border-t border-[#0F373E]/10">
                  <h3 className="text-xs uppercase tracking-[0.18em] font-bold text-[#0D3840] mb-3 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#0E3A42] text-white text-[10px] flex items-center justify-center font-sans">3</span>
                    Your Information
                  </h3>

                  <div className="space-y-3.5">
                    <div>
                      <label className="block text-xs font-medium text-[#204E57] mb-1 flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-[#185561]" />
                        <span>Full Name</span>
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Your full name"
                        value={bookingForm.name}
                        onChange={(e) => setBookingForm({ ...bookingForm, name: e.target.value })}
                        className="w-full bg-[#F5F9FA] border border-[#0F373E]/20 rounded-xs px-3.5 py-2.5 text-xs text-[#0D3840] focus:outline-hidden focus:border-[#0E3A42]"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-medium text-[#204E57] mb-1 flex items-center gap-1.5">
                          <Mail className="w-3.5 h-3.5 text-[#185561]" />
                          <span>Email Address</span>
                        </label>
                        <input
                          type="email"
                          required
                          placeholder="e.g. name@example.com"
                          value={bookingForm.email}
                          onChange={(e) => setBookingForm({ ...bookingForm, email: e.target.value })}
                          className="w-full bg-[#F5F9FA] border border-[#0F373E]/20 rounded-xs px-3.5 py-2.5 text-xs text-[#0D3840] focus:outline-hidden focus:border-[#0E3A42]"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-[#204E57] mb-1 flex items-center gap-1.5">
                          <Phone className="w-3.5 h-3.5 text-[#185561]" />
                          <span>Contact Number</span>
                        </label>
                        <input
                          type="tel"
                          required
                          placeholder="e.g. 09168623120"
                          value={bookingForm.phone}
                          onChange={(e) => setBookingForm({ ...bookingForm, phone: e.target.value })}
                          className="w-full bg-[#F5F9FA] border border-[#0F373E]/20 rounded-xs px-3.5 py-2.5 text-xs text-[#0D3840] focus:outline-hidden focus:border-[#0E3A42]"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-[#204E57] mb-1">
                        Specific Goals or Scheduling Notes (Optional)
                      </label>
                      <textarea
                        rows={2}
                        placeholder="Mention any study schedule details, burnout triggers, or preferences..."
                        value={bookingForm.notes}
                        onChange={(e) => setBookingForm({ ...bookingForm, notes: e.target.value })}
                        className="w-full bg-[#F5F9FA] border border-[#0F373E]/20 rounded-xs px-3.5 py-2 text-xs text-[#0D3840] focus:outline-hidden focus:border-[#0E3A42] resize-none"
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-[#0E3A42] hover:bg-[#07242A] text-white text-xs uppercase tracking-[0.2em] font-semibold py-3.5 rounded-xs transition-colors cursor-pointer shadow-xs disabled:opacity-50"
                  >
                    {loading ? 'CONFIRMING SCHEDULE...' : `CONFIRM ${activeServiceObj.title.toUpperCase()} SCHEDULE`}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
