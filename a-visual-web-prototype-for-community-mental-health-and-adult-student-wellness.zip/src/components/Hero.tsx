import { Play, Sparkles, Music, Bot } from 'lucide-react';
import { MusicTrack } from '../data/musicTracks';

interface HeroProps {
  onOpenBreathing: () => void;
  onExploreClick: () => void;
  onMusicClick?: () => void;
  onHealioClick?: () => void;
  currentTrack?: MusicTrack;
  isPlaying?: boolean;
}

export default function Hero({ onOpenBreathing, onExploreClick, onMusicClick, onHealioClick, currentTrack, isPlaying }: HeroProps) {
  return (
    <section id="hero" className="relative w-full overflow-hidden pt-10 pb-24 lg:pt-16 lg:pb-36 min-h-[680px] flex items-center bg-[#0F2F37]">
      {/* Home Page Background Image (download.jpg - Full Golden Sunset Beach with Birds) */}
      <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
        <img
          src="/src/assets/images/home_bg_sunset_birds_1790577858789.jpg"
          alt="Tranquil coastal sunset with sea birds flying over gentle waves"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center scale-100"
        />
        {/* Measured warm contrast scrim to keep the vibrant sunset completely visible while guaranteeing high text legibility */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#082228]/85 via-[#082228]/55 to-[#082228]/25" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0A262C]/90 via-transparent to-black/30" />
      </div>

      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 relative z-10 w-full py-10 lg:py-16">
        <div className="max-w-3xl">
          {/* Immediate Calming Music Live Indicator */}
          {currentTrack && (
            <button
              onClick={onMusicClick}
              className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-[#082228]/85 border border-white/25 text-xs text-[#FAF3EB] backdrop-blur-xs mb-5 hover:bg-[#061B20] transition-colors cursor-pointer shadow-md"
            >
              <span className="w-2 h-2 rounded-full bg-[#8CD7E5] animate-ping"></span>
              <span className="font-semibold text-[#8CD7E5]">Calming Music Active:</span>
              <span className="truncate max-w-[200px] sm:max-w-sm text-white/90">{currentTrack.title}</span>
            </button>
          )}

          {/* Title / Brand statement */}
          <div className="space-y-1">
            <h1 className="font-serif-display text-5xl sm:text-6xl lg:text-7xl xl:text-[6.2rem] font-light tracking-tight text-[#FAF3EB] leading-[0.94] uppercase drop-shadow-md">
              A GENTLE
              <br />
              PLACE
            </h1>
          </div>

          {/* Sub-kicker */}
          <div className="mt-8 mb-4">
            <p className="text-xs sm:text-sm font-semibold tracking-[0.24em] uppercase text-[#F1D6B8] drop-shadow-xs">
              COMMUNITY MENTAL HEALTH & ADULT-STUDENT WELLNESS
            </p>
            <p className="text-[11px] tracking-[0.18em] uppercase text-[#D2E7EC] mt-1 font-medium">
              A Visual Web Prototype for Restorative Education & Frontline Resilience
            </p>
          </div>

          {/* Editorial Manifesto */}
          <div className="max-w-xl mt-3">
            <p className="text-[#E7E2DA] text-base sm:text-lg leading-relaxed font-light drop-shadow-xs">
              We craft restorative spaces and clinical grounding that feel like a breath of ocean air—calm, purposeful, and designed for adult learners navigating work, life, and academic rigor.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="mt-9 flex flex-wrap items-center gap-4 sm:gap-5">
            <button
              onClick={onExploreClick}
              className="bg-[#F0E4D3] hover:bg-[#E3D3BE] text-[#0A262C] text-xs sm:text-sm uppercase tracking-[0.16em] font-bold px-7 py-3.5 rounded-sm transition-all duration-200 shadow-md hover:shadow-lg cursor-pointer text-center"
            >
              EXPLORE PATHWAYS
            </button>

            {onMusicClick && (
              <button
                onClick={onMusicClick}
                className="bg-[#0E3A42]/85 hover:bg-[#07242A] text-white text-xs sm:text-sm uppercase tracking-[0.16em] font-medium px-5 py-3.5 rounded-sm transition-all duration-200 cursor-pointer flex items-center gap-2 border border-white/20 shadow-md backdrop-blur-xs"
              >
                <Music className="w-4 h-4 text-[#8CD7E5]" />
                <span>CALMING MUSIC</span>
              </button>
            )}

            {onHealioClick && (
              <button
                onClick={onHealioClick}
                className="bg-[#114B56]/90 hover:bg-[#0D3840] text-white text-xs sm:text-sm uppercase tracking-[0.16em] font-medium px-4 py-2.5 rounded-sm transition-all duration-200 cursor-pointer flex items-center gap-2.5 border border-[#8CD7E5]/30 shadow-md backdrop-blur-xs group"
              >
                <div className="w-6 h-6 rounded-full overflow-hidden border border-[#8CD7E5]/60 shrink-0 shadow-xs">
                  <img
                    src="/src/assets/images/healio_counselor_portrait_1790580704967.jpg"
                    alt="Healio"
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform"
                  />
                </div>
                <span>TALK TO HEALIO</span>
              </button>
            )}

            <button
              onClick={onOpenBreathing}
              className="group flex items-center gap-2.5 text-xs sm:text-sm uppercase tracking-[0.16em] text-[#E7E2DA] hover:text-white font-medium transition-colors cursor-pointer py-2"
            >
              <span className="w-8 h-8 rounded-full border border-white/40 group-hover:border-white group-hover:bg-white/15 flex items-center justify-center transition-all duration-200 backdrop-blur-xs">
                <Play className="w-3.5 h-3.5 fill-white text-white ml-0.5" />
              </span>
              <span>WATCH BREATHWORK</span>
            </button>
          </div>

          {/* Live Adult Student Context Kicker */}
          <div className="mt-12 pt-6 border-t border-white/15 flex flex-wrap items-center gap-4 sm:gap-6 text-xs text-[#C5DCE2]">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              <span className="font-medium text-white">Confidential & Safe Sanctuary</span>
            </div>
            <span aria-hidden="true" className="text-white/40">·</span>
            <span>Treatment & Counseling</span>
            <span aria-hidden="true" className="text-white/40">·</span>
            <span>Community Advocacy</span>
          </div>
        </div>
      </div>
    </section>
  );
}
