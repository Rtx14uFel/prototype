import { X, CheckCircle, Target, ArrowRight } from 'lucide-react';
import { WellnessOffering } from '../types';

interface OfferingModalProps {
  offering: WellnessOffering | null;
  onClose: () => void;
  onConnect: (offering: WellnessOffering) => void;
}

export default function OfferingModal({ offering, onClose, onConnect }: OfferingModalProps) {
  if (!offering) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-[#092B32]/70 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-xl bg-[#EBF2F4] rounded-sm shadow-2xl border border-[#0F373E]/20 overflow-hidden my-8 p-6 sm:p-8">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 w-8 h-8 rounded-full bg-[#0E3A42]/10 hover:bg-[#0E3A42]/20 text-[#0E3A42] flex items-center justify-center transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-6">
          <span className="text-[10px] uppercase tracking-[0.24em] font-semibold text-[#2C6975]">
            SERVICE DEEP DIVE
          </span>
          <h3 className="font-serif-display text-3xl font-normal text-[#0D3840] mt-1">
            {offering.title}
          </h3>
        </div>

        <p className="text-sm text-[#1F4951] leading-relaxed font-light mb-6">
          {offering.fullDesc}
        </p>

        <div className="bg-white/80 p-4 rounded-xs border border-[#0F373E]/10 mb-6">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#0E3A42] mb-1">
            <Target className="w-4 h-4 text-[#1F6E7C]" />
            <span>Intended Demographic</span>
          </div>
          <p className="text-xs text-[#305963] leading-relaxed">
            {offering.audience}
          </p>
        </div>

        <div className="mb-8">
          <h4 className="text-xs uppercase tracking-[0.18em] font-bold text-[#0D3840] mb-3">
            Expected Wellness Outcomes
          </h4>
          <div className="space-y-2">
            {offering.outcomes.map((outcome, idx) => (
              <div key={idx} className="flex items-start gap-2.5 text-xs text-[#224C55]">
                <CheckCircle className="w-4 h-4 text-[#207B8C] shrink-0 mt-0.5" />
                <span>{outcome}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="pt-4 border-t border-[#0F373E]/10 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs uppercase tracking-widest font-medium text-[#1E4D56] hover:text-[#0A292E] transition-colors cursor-pointer"
          >
            Close
          </button>
          <button
            onClick={() => {
              onConnect(offering);
              onClose();
            }}
            className="bg-[#0E3A42] hover:bg-[#07252A] text-white text-xs uppercase tracking-[0.16em] font-medium px-5 py-2.5 rounded-xs transition-colors cursor-pointer flex items-center gap-2"
          >
            <span>Request Inquiry</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
