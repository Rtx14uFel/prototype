import { useState, useEffect } from 'react';
import { Menu, X, PhoneCall, Waves, Bot } from 'lucide-react';

interface HeaderProps {
  onOpenIntake: () => void;
  onOpenBreathing: () => void;
  onOpenHealio?: () => void;
}

export default function Header({ onOpenIntake, onOpenBreathing, onOpenHealio }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      <header
        className={`sticky top-0 z-40 w-full transition-all duration-300 ${
          scrolled
            ? 'bg-[#0B2A31]/95 backdrop-blur-md shadow-md border-b border-white/10 py-3 text-white'
            : 'bg-gradient-to-b from-[#082228]/80 via-[#082228]/40 to-transparent py-5 text-white'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 flex items-center justify-between">
          {/* Zone 1: Single wordmark element with subtle wave mark */}
          <a
            href="#"
            className="flex items-center gap-2 group text-white hover:opacity-90 transition-opacity"
          >
            <div className="flex flex-col">
              <span className="font-serif-display text-xl sm:text-2xl font-semibold tracking-wider uppercase text-[#FAF3EB] flex items-center gap-1.5 drop-shadow-xs">
                A GENTLE PLACE
                <Waves className="w-4 h-4 text-[#89D5E2] stroke-[1.5]" />
              </span>
              <span className="text-[9px] tracking-[0.2em] uppercase text-[#C7E4EB] font-medium hidden sm:inline-block">
                COMMUNITY MENTAL HEALTH & WELLNESS
              </span>
            </div>
          </a>

          {/* Zone 2: clean text navigation links */}
          <nav className="hidden md:flex items-center gap-6 lg:gap-8 text-xs uppercase tracking-[0.16em] font-medium text-[#E2EEF0]">
            <a href="#hero" className="hover:text-white hover:underline underline-offset-8 transition-colors">
              HOME
            </a>
            <a href="#pillars" className="hover:text-white hover:underline underline-offset-8 transition-colors">
              PILLARS
            </a>
            <a href="#offerings" className="hover:text-white hover:underline underline-offset-8 transition-colors">
              SERVICES
            </a>
            <a href="#wellness-lab" className="hover:text-white hover:underline underline-offset-8 transition-colors">
              WELLNESS LAB
            </a>
            <a href="#calming-music" className="text-[#89D5E2] font-semibold hover:text-white hover:underline underline-offset-8 transition-colors flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#89D5E2] animate-pulse"></span>
              MUSIC
            </a>
            {onOpenHealio && (
              <button
                onClick={onOpenHealio}
                className="text-[#FAF3EB] hover:text-[#8CD7E5] hover:underline underline-offset-8 transition-colors flex items-center gap-1.5 cursor-pointer uppercase font-medium"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                HEALIO AI
              </button>
            )}
            <a href="#schedule" className="hover:text-white hover:underline underline-offset-8 transition-colors">
              SCHEDULE
            </a>
            <a href="#contact" className="hover:text-white hover:underline underline-offset-8 transition-colors">
              CONTACT
            </a>
          </nav>

          {/* Zone 3: Primary action button */}
          <div className="hidden md:flex items-center gap-3">
            <button
              onClick={onOpenBreathing}
              className="text-xs uppercase tracking-widest text-[#D3EBF0] hover:text-white font-medium px-3 py-2 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-[#3AA1B4] animate-pulse"></span>
              QUICK CALM
            </button>
            <button
              onClick={onOpenIntake}
              className="bg-[#F0E4D3] hover:bg-[#E3D3BE] text-[#0A262C] text-xs uppercase tracking-[0.16em] font-bold px-5 py-2.5 rounded-sm transition-all duration-200 shadow-sm hover:shadow-md cursor-pointer whitespace-nowrap"
            >
              LET'S TALK
            </button>
          </div>

          {/* Mobile menu hamburger toggle */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={onOpenBreathing}
              className="text-xs bg-white/20 text-white px-2.5 py-1.5 rounded-sm font-medium backdrop-blur-xs cursor-pointer"
            >
              Breathe
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-white rounded-md focus:outline-hidden hover:bg-white/15 transition-colors cursor-pointer"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 bg-[#0E3A42]/50 backdrop-blur-xs md:hidden flex justify-end">
          <div className="w-4/5 max-w-sm bg-[#EBF2F4] h-full shadow-2xl p-6 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-6 border-b border-[#0F373E]/15">
                <span className="font-serif-display text-xl font-bold tracking-wider text-[#0E3A42]">
                  A GENTLE PLACE
                </span>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-1 text-[#0E3A42] hover:bg-[#D5E4E8] rounded-sm"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="mt-8 flex flex-col gap-5 text-sm uppercase tracking-widest font-medium text-[#1E4D57]">
                <a
                  href="#hero"
                  onClick={() => setMobileMenuOpen(false)}
                  className="py-2 hover:text-[#0E3A42] transition-colors"
                >
                  Home
                </a>
                <a
                  href="#pillars"
                  onClick={() => setMobileMenuOpen(false)}
                  className="py-2 hover:text-[#0E3A42] transition-colors"
                >
                  Pillars & Work
                </a>
                <a
                  href="#offerings"
                  onClick={() => setMobileMenuOpen(false)}
                  className="py-2 hover:text-[#0E3A42] transition-colors"
                >
                  Services
                </a>
                <a
                  href="#wellness-lab"
                  onClick={() => setMobileMenuOpen(false)}
                  className="py-2 hover:text-[#0E3A42] transition-colors"
                >
                  Interactive Wellness Lab
                </a>
                <a
                  href="#calming-music"
                  onClick={() => setMobileMenuOpen(false)}
                  className="py-2 text-[#0E3A42] font-semibold flex items-center justify-between transition-colors"
                >
                  <span>Calming Music Sanctuary</span>
                  <span className="w-2 h-2 rounded-full bg-[#1F7B8C]"></span>
                </a>
                {onOpenHealio && (
                  <button
                    onClick={() => {
                      setMobileMenuOpen(false);
                      onOpenHealio();
                    }}
                    className="py-2 text-[#0E3A42] font-semibold flex items-center justify-between transition-colors w-full text-left cursor-pointer"
                  >
                    <span>Healio (AI Counselor)</span>
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  </button>
                )}
                <a
                  href="#schedule"
                  onClick={() => setMobileMenuOpen(false)}
                  className="py-2 hover:text-[#0E3A42] transition-colors"
                >
                  Schedule for Care
                </a>
                <a
                  href="#contact"
                  onClick={() => setMobileMenuOpen(false)}
                  className="py-2 hover:text-[#0E3A42] transition-colors"
                >
                  Contact & Intake
                </a>
              </div>
            </div>

            <div className="space-y-4 pt-6 border-t border-[#0F373E]/15">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenIntake();
                }}
                className="w-full bg-[#0E3A42] text-white py-3 text-xs uppercase tracking-widest font-medium rounded-sm"
              >
                Let's Talk / Intake
              </button>
              <div className="p-3 rounded-sm bg-[#D8E7EB] text-xs text-[#0A2C33] space-y-1">
                <div>
                  <span className="font-semibold text-[#0E3A42]">Direct Phone:</span>{' '}
                  <a href="tel:09168623120" className="underline">09168623120</a>
                </div>
                <div>
                  <span className="font-semibold text-[#0E3A42]">Email:</span>{' '}
                  <a href="mailto:gregoriorivera654@gmail.com" className="underline">gregoriorivera654@gmail.com</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
