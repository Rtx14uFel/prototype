import { PenTool, Layout, Smartphone, Camera, ArrowRight } from 'lucide-react';
import { OFFERINGS } from '../data/wellnessData';
import { WellnessOffering } from '../types';

interface OfferingsSectionProps {
  onSelectOffering: (offering: WellnessOffering) => void;
  onConsultationClick: () => void;
}

export default function OfferingsSection({ onSelectOffering, onConsultationClick }: OfferingsSectionProps) {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'pen':
        return <PenTool className="w-8 h-8 text-[#14535F] stroke-[1.25]" />;
      case 'window':
        return <Layout className="w-8 h-8 text-[#14535F] stroke-[1.25]" />;
      case 'smartphone':
        return <Smartphone className="w-8 h-8 text-[#14535F] stroke-[1.25]" />;
      case 'camera':
      default:
        return <Camera className="w-8 h-8 text-[#14535F] stroke-[1.25]" />;
    }
  };

  return (
    <section id="offerings" className="w-full py-16 sm:py-24 border-t border-[#0F373E]/10">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
          {/* Left Column: Heading and Manifesto */}
          <div className="lg:col-span-4 flex flex-col justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.22em] text-[#366772] font-semibold mb-2">
                WHAT WE DO
              </p>
              <h2 className="font-serif-display text-4xl sm:text-5xl font-normal tracking-tight text-[#0D3840] leading-tight mb-5">
                Care that Moves with Meaning
              </h2>
              <p className="text-sm sm:text-base text-[#254C54] leading-relaxed font-light mb-8 max-w-md">
                We help non-traditional adult learners, night students, and community caregivers build lasting psychological safety through thoughtful peer systems and trauma-informed rest practices.
              </p>
            </div>

            <div>
              <button
                onClick={onConsultationClick}
                className="border border-[#0E3A42] text-[#0E3A42] hover:bg-[#0E3A42] hover:text-[#E8F3F5] text-xs uppercase tracking-[0.18em] font-medium px-6 py-3 rounded-xs transition-all duration-200 cursor-pointer shadow-2xs"
              >
                LET'S WORK TOGETHER
              </button>
            </div>
          </div>

          {/* Right Column: 4 Columns with Clean Line Icons matching reference */}
          <div className="lg:col-span-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-8 lg:gap-6">
              {OFFERINGS.map((offering) => (
                <div
                  key={offering.id}
                  className="flex flex-col justify-between group p-2 hover:bg-[#DEEBEE]/40 rounded-sm transition-colors duration-200"
                >
                  <div>
                    {/* Icon container matching reference's clean minimalist line art */}
                    <div className="w-12 h-12 flex items-center justify-center mb-6">
                      {getIcon(offering.iconName)}
                    </div>

                    <h3 className="text-xs uppercase tracking-[0.16em] font-bold text-[#0D3840] mb-3">
                      {offering.title}
                    </h3>

                    <p className="text-xs text-[#2A515A] leading-relaxed font-light mb-6">
                      {offering.shortDesc}
                    </p>
                  </div>

                  <div>
                    <button
                      onClick={() => onSelectOffering(offering)}
                      className="inline-flex items-center gap-1.5 text-[11px] uppercase tracking-[0.18em] font-semibold text-[#18535F] group-hover:text-[#092B32] transition-colors cursor-pointer"
                    >
                      <span>LEARN MORE</span>
                      <ArrowRight className="w-3 h-3 transition-transform duration-200 group-hover:translate-x-1" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
