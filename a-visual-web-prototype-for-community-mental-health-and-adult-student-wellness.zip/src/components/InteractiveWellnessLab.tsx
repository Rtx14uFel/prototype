import { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX, RotateCcw, CheckCircle2, Copy } from 'lucide-react';
import { DIAGNOSTIC_QUESTIONS } from '../data/wellnessData';

export default function InteractiveWellnessLab() {
  // --- 1. Breathing Circle State ---
  const [breathPhase, setBreathPhase] = useState<'Inhale' | 'Hold' | 'Exhale'>('Inhale');
  const [breathSecondsLeft, setBreathSecondsLeft] = useState(4);
  const [isBreathingActive, setIsBreathingActive] = useState(false);
  const [breathCyclesCompleted, setBreathCyclesCompleted] = useState(0);
  const [isAudioMuted, setIsAudioMuted] = useState(true);

  // Web Audio ocean sound generator ref
  const audioCtxRef = useRef<AudioContext | null>(null);
  const noiseNodeRef = useRef<AudioNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);

  // Start / stop breathing loop
  useEffect(() => {
    if (!isBreathingActive) return;

    const timer = setInterval(() => {
      setBreathSecondsLeft((prev) => {
        if (prev > 1) return prev - 1;

        // Transition phases: Inhale (4s) -> Hold (7s) -> Exhale (8s)
        if (breathPhase === 'Inhale') {
          setBreathPhase('Hold');
          return 7;
        } else if (breathPhase === 'Hold') {
          setBreathPhase('Exhale');
          return 8;
        } else {
          setBreathPhase('Inhale');
          setBreathCyclesCompleted((c) => c + 1);
          return 4;
        }
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isBreathingActive, breathPhase]);

  // Audio tone/wave modulation
  useEffect(() => {
    if (isAudioMuted) {
      if (gainNodeRef.current) {
        gainNodeRef.current.gain.setValueAtTime(0, audioCtxRef.current?.currentTime || 0);
      }
      return;
    }

    try {
      if (!audioCtxRef.current) {
        const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        audioCtxRef.current = new AudioContextClass();
      }

      if (audioCtxRef.current.state === 'suspended') {
        audioCtxRef.current.resume();
      }

      if (!gainNodeRef.current) {
        // Create pink/brown noise simulation for soft ocean surf
        const bufferSize = audioCtxRef.current.sampleRate * 2;
        const noiseBuffer = audioCtxRef.current.createBuffer(1, bufferSize, audioCtxRef.current.sampleRate);
        const output = noiseBuffer.getChannelData(0);
        let b0 = 0, b1 = 0, b2 = 0;
        for (let i = 0; i < bufferSize; i++) {
          const white = Math.random() * 2 - 1;
          b0 = 0.99886 * b0 + white * 0.0555179;
          b1 = 0.99332 * b1 + white * 0.0750759;
          b2 = 0.96900 * b2 + white * 0.1538520;
          output[i] = (b0 + b1 + b2) * 0.08;
        }

        const whiteNoise = audioCtxRef.current.createBufferSource();
        whiteNoise.buffer = noiseBuffer;
        whiteNoise.loop = true;

        const filter = audioCtxRef.current.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.value = 380;

        const gainNode = audioCtxRef.current.createGain();
        gainNode.gain.setValueAtTime(0.06, audioCtxRef.current.currentTime);

        whiteNoise.connect(filter);
        filter.connect(gainNode);
        gainNode.connect(audioCtxRef.current.destination);
        whiteNoise.start(0);

        noiseNodeRef.current = whiteNoise;
        gainNodeRef.current = gainNode;
      } else {
        gainNodeRef.current.gain.setValueAtTime(0.06, audioCtxRef.current.currentTime);
      }
    } catch {
      // Audio not permitted without user gesture or unsupported
    }
  }, [isAudioMuted]);

  // --- 2. Diagnostic Questionnaire State ---
  const [answers, setAnswers] = useState<Record<string, number>>({
    q1: 2,
    q2: 2,
    q3: 2,
    q4: 2
  });
  const [copiedPlan, setCopiedPlan] = useState(false);

  const totalScore = Object.values(answers).reduce((a, b) => a + b, 0);

  const getScoreDiagnosis = (score: number) => {
    if (score <= 6) {
      return {
        level: 'Regulated Equilibrium',
        color: 'text-emerald-700 bg-emerald-50 border-emerald-200',
        summary: 'Your emotional and cognitive reserves are currently stable. Focus on sustainable micro-habits before midterms.',
        protocol: 'Maintain 10-minute transition pauses between job sign-off and class sign-on.'
      };
    } else if (score <= 10) {
      return {
        level: 'Moderate Adult-Student Strain',
        color: 'text-amber-800 bg-amber-50/80 border-amber-200',
        summary: 'Noticeable friction between vocational obligations and collegiate deadlines. Your nervous system is carrying latent tension.',
        protocol: 'Incorporate 4-7-8 breathing before study sessions. Consider joining the Twilight Scholars Circle.'
      };
    } else {
      return {
        level: 'High Autonomic Overload / Impending Burnout',
        color: 'text-rose-800 bg-rose-50 border-rose-200',
        summary: 'Your physiological and emotional boundaries are heavily strained. You are running on cortisol reserves.',
        protocol: 'Schedule a treatment consultation. Take tonight to step away from academic screens and rest.'
      };
    }
  };

  const diagnosis = getScoreDiagnosis(totalScore);

  const handleCopyPlan = () => {
    const text = `ADULT-STUDENT RESTORATIVE CARE PLAN\nDiagnosis: ${diagnosis.level}\nTotal Fatigue Index: ${totalScore}/16\nRecommended Protocol: ${diagnosis.protocol}\nGuidance: Support available at A Gentle Place (Contact: 09168623120 / gregoriorivera654@gmail.com)`;
    navigator.clipboard.writeText(text);
    setCopiedPlan(true);
    setTimeout(() => setCopiedPlan(false), 2500);
  };

  return (
    <section id="wellness-lab" className="w-full py-16 sm:py-24 border-t border-[#0F373E]/10 bg-[#E5EEF0]/60">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-xs uppercase tracking-[0.22em] text-[#366772] font-semibold mb-2">
            REST & RECOVERY LAB
          </p>
          <h2 className="font-serif-display text-4xl sm:text-5xl font-normal tracking-tight text-[#0D3840]">
            Interactive Student Wellness Suite
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#254C54] font-light">
            Evidence-based somatic down-regulation, personalized academic burnout triage, and community cohort connection.
          </p>
        </div>

        {/* Dual Interactive Modules Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-16">
          {/* Module 1: Guided 4-7-8 Breathing Sphere */}
          <div className="lg:col-span-5 bg-[#F2F7F8] p-8 rounded-sm border border-[#0F373E]/12 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-[#0F373E]/10">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#207B8C]"></span>
                  <h3 className="text-xs uppercase tracking-[0.18em] font-bold text-[#0D3840]">
                    4-7-8 Somatic Ocean Breath
                  </h3>
                </div>
                <button
                  onClick={() => setIsAudioMuted(!isAudioMuted)}
                  className="p-1.5 rounded-sm hover:bg-[#DEEBEE] text-[#1B5661] transition-colors"
                  title={isAudioMuted ? 'Turn on ocean waves' : 'Mute ocean waves'}
                >
                  {isAudioMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-emerald-700" />}
                </button>
              </div>

              <p className="text-xs text-[#355B63] mt-3">
                Used to quickly activate the vagus nerve and shift adult brains from high-stress work mode into calm retention.
              </p>
            </div>

            {/* Visual Breathing Sphere Container */}
            <div className="my-8 flex flex-col items-center justify-center min-h-[220px]">
              <div className="relative flex items-center justify-center">
                {/* Outer pulsing ring */}
                <div
                  className={`w-44 h-44 rounded-full border border-[#2B7988]/30 flex items-center justify-center transition-all duration-1000 ${
                    breathPhase === 'Inhale'
                      ? 'scale-110 bg-[#D4E8EC]/50'
                      : breathPhase === 'Hold'
                      ? 'scale-110 bg-[#C4DFE4]/70 border-[#2B7988]/60'
                      : 'scale-90 bg-[#E2EFF2]/30'
                  }`}
                >
                  {/* Inner orb */}
                  <div
                    className={`w-32 h-32 rounded-full shadow-inner flex flex-col items-center justify-center transition-all duration-700 ${
                      breathPhase === 'Inhale'
                        ? 'bg-[#A8CCD4] scale-105'
                        : breathPhase === 'Hold'
                        ? 'bg-[#92BAC3] scale-100'
                        : 'bg-[#BBD7DD] scale-95'
                    }`}
                  >
                    <span className="text-[11px] uppercase tracking-widest font-semibold text-[#0B333B]">
                      {isBreathingActive ? breathPhase : 'READY'}
                    </span>
                    <span className="text-3xl font-serif-display font-bold text-[#0B333B] tabular-nums mt-0.5">
                      {isBreathingActive ? breathSecondsLeft : '4-7-8'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Instructions */}
              <p className="text-xs text-[#2A525A] text-center mt-5 font-medium max-w-xs">
                {isBreathingActive ? (
                  breathPhase === 'Inhale'
                    ? 'Inhale calmly through your nose for 4s...'
                    : breathPhase === 'Hold'
                    ? 'Gently pause and suspend your breath for 7s...'
                    : 'Slowly exhale through your mouth for 8s...'
                ) : (
                  'Click Start to begin a guided 3-minute evening decompression cycle.'
                )}
              </p>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-between pt-4 border-t border-[#0F373E]/10">
              <span className="text-xs text-[#416871] tabular-nums">
                Cycles Completed: <strong className="text-[#0E3A42]">{breathCyclesCompleted}</strong>
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setIsBreathingActive(false);
                    setBreathPhase('Inhale');
                    setBreathSecondsLeft(4);
                  }}
                  className="p-2 text-[#3D646D] hover:text-[#0E3A42] hover:bg-[#DEEBEE] rounded-sm transition-colors"
                  title="Reset breath timer"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>

                <button
                  onClick={() => setIsBreathingActive(!isBreathingActive)}
                  className={`text-xs uppercase tracking-widest font-semibold px-4 py-2 rounded-xs transition-colors cursor-pointer ${
                    isBreathingActive
                      ? 'bg-[#29565F] text-white hover:bg-[#1B4047]'
                      : 'bg-[#0E3A42] text-white hover:bg-[#07242A]'
                  }`}
                >
                  {isBreathingActive ? 'Pause Session' : 'Start Session'}
                </button>
              </div>
            </div>
          </div>

          {/* Module 2: Adult-Student Stress & Balance Diagnostic */}
          <div className="lg:col-span-7 bg-[#F2F7F8] p-8 rounded-sm border border-[#0F373E]/12 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-[#0F373E]/10">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#1A7789]"></span>
                  <h3 className="text-xs uppercase tracking-[0.18em] font-bold text-[#0D3840]">
                    Adult-Student Fatigue & Pacing Diagnostic
                  </h3>
                </div>
                <span className="text-xs font-semibold text-[#18535F] tabular-nums">
                  Index: {totalScore}/16
                </span>
              </div>

              <div className="mt-5 space-y-4">
                {DIAGNOSTIC_QUESTIONS.map((q) => (
                  <div key={q.id} className="bg-white/70 p-3.5 rounded-sm border border-[#0F373E]/8">
                    <p className="text-xs font-semibold text-[#0E3A42] mb-1.5">
                      {q.title}
                    </p>
                    <p className="text-[11px] text-[#365D65] mb-2">{q.question}</p>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                      {q.options.map((opt) => {
                        const isSelected = answers[q.id] === opt.score;
                        return (
                          <button
                            key={opt.score}
                            onClick={() =>
                              setAnswers((prev) => ({
                                ...prev,
                                [q.id]: opt.score
                              }))
                            }
                            className={`p-1.5 text-[10px] rounded-xs text-left transition-all leading-tight cursor-pointer ${
                              isSelected
                                ? 'bg-[#0E3A42] text-white font-medium shadow-2xs'
                                : 'bg-[#EBF2F4] text-[#1D4A52] hover:bg-[#DCEBF0]'
                            }`}
                          >
                            {opt.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Diagnostic Evaluation Card */}
            <div className="mt-6 pt-4 border-t border-[#0F373E]/10">
              <div className={`p-4 rounded-sm border ${diagnosis.color} flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4`}>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span className="text-xs uppercase tracking-wider font-bold">
                      {diagnosis.level}
                    </span>
                  </div>
                  <p className="text-xs font-light leading-relaxed max-w-md">
                    {diagnosis.summary}
                  </p>
                  <p className="text-xs font-medium mt-1">
                    Next step: {diagnosis.protocol}
                  </p>
                </div>

                <button
                  onClick={handleCopyPlan}
                  className="bg-[#0E3A42] hover:bg-[#07252A] text-white text-[11px] uppercase tracking-wider font-medium px-3.5 py-2 rounded-xs shrink-0 flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedPlan ? 'Copied Plan!' : 'Copy Plan'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
