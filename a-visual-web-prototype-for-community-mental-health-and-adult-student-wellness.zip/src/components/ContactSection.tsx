import { useState } from 'react';
import { Mail, Phone, CheckCircle2, ShieldAlert } from 'lucide-react';
import { CohortCircle } from '../types';

interface ContactSectionProps {
  selectedCohort?: CohortCircle | null;
}

export default function ContactSection({ selectedCohort }: ContactSectionProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    pathway: selectedCohort ? selectedCohort.name : 'Individual Counseling Consultation',
    message: ''
  });

  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
    }, 600);
  };

  return (
    <footer id="contact" className="w-full bg-[#0B353D] text-[#E8F3F5] pt-20 pb-12">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Main 2-Column Contact Block matching reference image */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 pb-16 border-b border-white/10">
          {/* Left Column: Get In Touch */}
          <div className="lg:col-span-5 flex flex-col justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.22em] text-[#69A3AF] font-semibold mb-3">
                GET IN TOUCH
              </p>
              <h2 className="font-serif-display text-4xl sm:text-5xl font-light text-white leading-tight mb-6">
                Let's Foster Healing Together
              </h2>
              <p className="text-xs sm:text-sm text-[#A2C9D1] font-light leading-relaxed max-w-sm mb-8">
                Whether you are a night student needing peer validation, a community partner seeking workshops, or a frontline worker seeking sliding-scale therapy, our doors are open.
              </p>
            </div>

            <div className="space-y-4">
              <div className="flex items-center gap-3 text-xs sm:text-sm text-[#D7EBEF]">
                <Mail className="w-4 h-4 text-[#69A3AF] shrink-0" />
                <a href="mailto:gregoriorivera654@gmail.com" className="hover:underline">
                  gregoriorivera654@gmail.com
                </a>
              </div>

              <div className="flex items-center gap-3 text-xs sm:text-sm text-[#D7EBEF]">
                <Phone className="w-4 h-4 text-[#69A3AF] shrink-0" />
                <a href="tel:09168623120" className="hover:underline">
                  09168623120
                </a>
              </div>
            </div>
          </div>

          {/* Right Column: Clean Minimalist Form matching reference */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            {submitted ? (
              <div className="bg-[#12454F] p-8 rounded-xs border border-white/15 text-center space-y-4">
                <div className="flex justify-center">
                  <CheckCircle2 className="w-10 h-10 text-emerald-300" />
                </div>
                <h3 className="font-serif-display text-2xl text-white">
                  Intake Request Received
                </h3>
                <p className="text-xs text-[#BEDCE2] max-w-md mx-auto leading-relaxed">
                  Thank you for reaching out. A community wellness coordinator will quietly review your note and reach out within 24 hours with confidential cohort access and sliding-scale matching.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="mt-4 text-xs uppercase tracking-widest text-[#E6DDD3] hover:underline"
                >
                  Send another inquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Row 1: Your Name & Email Address */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="name" className="sr-only">Your Name</label>
                    <input
                      id="name"
                      type="text"
                      required
                      placeholder="Your Name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full bg-transparent border border-white/25 rounded-xs px-4 py-3 text-xs sm:text-sm text-white placeholder-white/50 focus:outline-hidden focus:border-white transition-colors"
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="sr-only">Email Address</label>
                    <input
                      id="email"
                      type="email"
                      required
                      placeholder="Email Address"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full bg-transparent border border-white/25 rounded-xs px-4 py-3 text-xs sm:text-sm text-white placeholder-white/50 focus:outline-hidden focus:border-white transition-colors"
                    />
                  </div>
                </div>

                {/* Row 2: Pathway / Program Type Dropdown */}
                <div>
                  <label htmlFor="pathway" className="sr-only">Pathway / Program</label>
                  <select
                    id="pathway"
                    value={formData.pathway}
                    onChange={(e) => setFormData({ ...formData, pathway: e.target.value })}
                    className="w-full bg-[#0B353D] border border-white/25 rounded-xs px-4 py-3 text-xs sm:text-sm text-white focus:outline-hidden focus:border-white transition-colors"
                  >
                    <option value="Twilight Scholars Peer Cohort">Twilight Scholars (Evening Adult Students)</option>
                    <option value="Parenting & Caregiving Learners">Parenting & Caregiving Learners</option>
                    <option value="First-Gen Navigator Pod">First-Gen Scholar Resilience Pod</option>
                    <option value="Low-Barrier Clinical Triage">Low-Barrier 1-on-1 Clinical Counseling</option>
                    <option value="Campus / Civic Partnership">Campus / Civic Organization Partnership</option>
                    <option value="Micro-Rest & Somatic Workshop">Micro-Rest & Somatic Workshop Request</option>
                  </select>
                </div>

                {/* Row 3: Message Textarea */}
                <div>
                  <label htmlFor="message" className="sr-only">Tell us about your wellness goals or student schedule</label>
                  <textarea
                    id="message"
                    required
                    rows={4}
                    placeholder="Tell us about your student schedule, burnout triggers, or support needs..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full bg-transparent border border-white/25 rounded-xs px-4 py-3 text-xs sm:text-sm text-white placeholder-white/50 focus:outline-hidden focus:border-white transition-colors resize-none"
                  ></textarea>
                </div>

                {/* Row 4: Submit Button matching reference sand-colored pill */}
                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={loading}
                    className="bg-[#E6DDD3] hover:bg-[#DCD2C6] text-[#0B353D] text-xs uppercase tracking-[0.2em] font-bold px-7 py-3.5 rounded-xs transition-colors cursor-pointer shadow-xs disabled:opacity-50"
                  >
                    {loading ? 'SENDING...' : 'SEND MESSAGE'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>

        {/* Bottom Footer Bar matching reference */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-[11px] uppercase tracking-[0.16em] text-[#69A3AF] font-medium gap-4">
          <div>
            © 2026 A GENTLE PLACE · A VISUAL WEB PROTOTYPE FOR COMMUNITY MENTAL HEALTH & ADULT-STUDENT WELLNESS
          </div>
          <div>
            DESIGNED WITH PURPOSE. DRIVEN BY COMMUNITY.
          </div>
        </div>
      </div>
    </footer>
  );
}
