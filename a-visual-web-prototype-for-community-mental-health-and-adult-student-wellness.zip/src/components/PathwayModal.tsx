import { X, Calendar, Users, CheckCircle, ShieldCheck } from 'lucide-react';
import { PathwayItem } from '../types';

interface PathwayModalProps {
  pathway: PathwayItem | null;
  onClose: () => void;
  onEnroll: (pathway: PathwayItem) => void;
}

export default function PathwayModal({ pathway, onClose, onEnroll }: PathwayModalProps) {
  if (!pathway) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-[#092B32]/70 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-[#EBF2F4] rounded-sm shadow-2xl border border-[#0F373E]/20 overflow-hidden my-8">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 w-9 h-9 rounded-full bg-[#0E3A42]/10 hover:bg-[#0E3A42]/20 text-[#0E3A42] flex items-center justify-center transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header Image */}
        <div className="relative h-56 sm:h-64 w-full bg-[#D5E5E9]">
          <img
            src={pathway.image}
            alt={pathway.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0E3A42]/80 via-transparent to-transparent flex items-end p-6">
            <div>
              <span className="text-[10px] uppercase tracking-[0.24em] font-semibold text-[#B3DFE8]">
                {pathway.category}
              </span>
              <h3 className="font-serif-display text-3xl sm:text-4xl text-white font-medium">
                {pathway.title}
              </h3>
            </div>
          </div>
        </div>

        {/* Modal Content */}
        <div className="p-6 sm:p-8 space-y-6">
          <p className="text-sm sm:text-base text-[#1E4B54] leading-relaxed font-light">
            {pathway.description}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div className="bg-white/70 p-4 rounded-xs border border-[#0F373E]/10">
              <div className="flex items-center gap-2 text-xs font-semibold text-[#0E3A42] mb-1">
                <Users className="w-4 h-4 text-[#1C5D6B]" />
                <span>Target Focus</span>
              </div>
              <p className="text-xs text-[#315862] leading-relaxed">
                {pathway.targetAudience}
              </p>
            </div>

            <div className="bg-white/70 p-4 rounded-xs border border-[#0F373E]/10">
              <div className="flex items-center gap-2 text-xs font-semibold text-[#0E3A42] mb-1">
                <Calendar className="w-4 h-4 text-[#1C5D6B]" />
                <span>Cadence & Schedule</span>
              </div>
              <p className="text-xs text-[#315862] leading-relaxed">
                {pathway.schedule}
              </p>
            </div>
          </div>

          {/* Key Practices */}
          <div>
            <h4 className="text-xs uppercase tracking-[0.18em] font-bold text-[#0E3A42] mb-3">
              Core Interventions & Somatic Exercises
            </h4>
            <div className="space-y-2">
              {pathway.keyPractices.map((practice, idx) => (
                <div key={idx} className="flex items-start gap-2.5 text-xs text-[#224C55]">
                  <CheckCircle className="w-4 h-4 text-[#207B8C] shrink-0 mt-0.5" />
                  <span>{practice}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Clinical Framework */}
          <div className="p-4 bg-[#DCE8EB] rounded-xs text-xs text-[#13444D] flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 text-[#185B68] shrink-0 mt-0.5" />
            <div>
              <strong className="font-semibold">Clinical Basis: </strong>
              {pathway.clinicalBasis}
            </div>
          </div>

          {/* Footer Actions */}
          <div className="pt-4 border-t border-[#0F373E]/10 flex items-center justify-end gap-3">
            <button
              onClick={onClose}
              className="px-5 py-2.5 text-xs uppercase tracking-widest font-medium text-[#1E4D56] hover:text-[#0A292E] transition-colors cursor-pointer"
            >
              Close
            </button>
            <button
              onClick={() => {
                onEnroll(pathway);
                onClose();
              }}
              className="bg-[#0E3A42] hover:bg-[#07252A] text-white text-xs uppercase tracking-[0.18em] font-medium px-6 py-2.5 rounded-xs transition-colors cursor-pointer"
            >
              Join Pathway
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
