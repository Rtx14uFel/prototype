export interface MusicTrack {
  id: string;
  youtubeId: string;
  title: string;
  artist: string;
  description: string;
  badge: string;
  idealFor: string;
  duration?: string;
}

export const CALMING_TRACKS: MusicTrack[] = [
  {
    id: 'track-1',
    youtubeId: '77ZozI0rw7w',
    title: 'Dreamy Piano & Nostalgic Serenity',
    artist: 'Ghibli Inspired Piano Sanctuary',
    description: 'Gentle, flowing acoustic piano chords and nostalgic peaceful melodies that bring immediate emotional calm and solace to an exhausted mind.',
    badge: 'Peaceful Piano',
    idealFor: 'Overwhelm reduction, gentle evening journaling, peaceful unwind'
  },
  {
    id: 'track-2',
    youtubeId: '_4kHxtiuML0',
    title: 'Chill Lofi Beats & Rain Reverie',
    artist: 'Cozy Study & Midnight Focus',
    description: 'Subtle mellow beats, warm Rhodes chords, and soothing rain textures designed to ease study dread and promote effortless focus.',
    badge: 'Chill Lofi',
    idealFor: 'Deep study sessions, quiet focus, anxiety-free reading'
  },
  {
    id: 'track-3',
    youtubeId: 'xRcWlA1I9z0',
    title: 'Acoustic Warmth & Gentle Fingerpicking',
    artist: 'Mellow Acoustic Guitar Sanctuary',
    description: 'Intimate, warm acoustic guitar melodies providing an organic, grounding ambiance like an afternoon porch facing the sea.',
    badge: 'Acoustic Calm',
    idealFor: 'Decompressing after intense work shifts, nervous system grounding'
  },
  {
    id: 'track-4',
    youtubeId: '9Zq79uu_o5E',
    title: 'Ethereal Ambient Waves & Deep Release',
    artist: 'Sublime Atmospheric Soundscapes',
    description: 'Expansive atmospheric pads, gentle sub-frequencies, and oceanic reverb that dissolve stress, racing thoughts, and mental clutter.',
    badge: 'Ambient Waves',
    idealFor: 'Restless minds, somatic breathing, emotional release'
  },
  {
    id: 'track-5',
    youtubeId: 'tNjOqzkJ2CE',
    title: 'Ocean Shoreline & Sleep Resonance',
    artist: 'Nighttime Coastal Slumber',
    description: 'Rhythmic rolling surf blended with sedative sleep frequencies engineered for deep restorative rest and insomnia relief.',
    badge: 'Deep Sleep',
    idealFor: 'Sleep preparation, deep REM recharge, night shift decompression'
  },
  {
    id: 'track-6',
    youtubeId: 'Pg6t-HMj2jg',
    title: 'Celestial Stillness & Soft Solitude',
    artist: 'Gentle Healing Frequencies',
    description: 'Tranquil celestial tones and gentle harmonic resonance to clear mental fatigue and center your inner sanctuary.',
    badge: 'Celestial Calm',
    idealFor: 'Morning centering, somatic relaxation, deep renewal'
  },
  {
    id: 'track-7',
    youtubeId: '1ZYbU82GVz4',
    title: 'Deep Serenity & Restorative Peace',
    artist: 'Restorative Piano & Atmospheric Waves',
    description: 'Soft harmonic frequencies and tranquil piano chords designed to down-regulate high autonomic arousal and relieve mental strain.',
    badge: 'Deep Rest',
    idealFor: 'Post-study recovery, emotional tension release, nervous system reset'
  },
  {
    id: 'track-8',
    youtubeId: 'I3OJUwILelU',
    title: 'Peaceful Acoustic & Soft Harmonies',
    artist: 'Tranquil Acoustic Sanctuary',
    description: 'Gentle, heartwarming strings and gentle acoustic textures providing a steady, comforting rhythm for non-traditional scholars.',
    badge: 'Focus & Study',
    idealFor: 'Concentration, reading without anxiety, mindful breaks'
  },
  {
    id: 'track-9',
    youtubeId: 'z-qigE1ym40',
    title: 'Continuous Ocean Flow & Lofi Calm',
    artist: '24/7 Live Sanctuary Stream',
    description: 'Continuous uninterrupted stream of calm ambient vibes and gentle coastal flow. Play quietly in the background as you unwind or sleep.',
    badge: 'Live 24/7',
    idealFor: 'Bedtime relaxation, extended focus, background sanctuary'
  }
];
