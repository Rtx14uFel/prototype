import { PathwayItem, WellnessOffering, TestimonialItem, CohortCircle } from '../types';

export const PATHWAYS: PathwayItem[] = [
  {
    id: 'coastal-grounding',
    title: 'COASTAL GROUNDING',
    category: 'SOMATIC REGULATION',
    subtitle: 'Nervous System Reset',
    image: '/src/assets/images/pillar_coastal_grounding_1790575156864.jpg',
    description: 'Evidence-based somatic practices designed to down-regulate acute cortisol spikes during intensive midterms, evening work shifts, and acute burnout.',
    targetAudience: 'Working adult scholars experiencing chronic autonomic overload and study-related tension headaches.',
    schedule: 'Bi-weekly on Tuesdays & Thursdays, 7:30 PM (PST)',
    keyPractices: [
      '5-minute physiological sigh & auditory wave entrainment',
      'Progressive muscle de-escalation for desk posture tension',
      'Polyvagal self-soothing gestures for academic exam dread'
    ],
    clinicalBasis: 'Grounded in Stephen Porges’ Polyvagal Theory and somatic sensory integration to restore parasympathetic tone.'
  },
  {
    id: 'night-scholar-cohorts',
    title: 'NIGHT SCHOLAR CIRCLES',
    category: 'PEER RESILIENCE',
    subtitle: 'Adult-Learner Solidarity',
    image: '/src/assets/images/pillar_adult_student_1790575168370.jpg',
    description: 'Facilitated peer circles specifically structured around the lived reality of students balancing full-time employment, caregiving, and late-night coursework.',
    targetAudience: 'Non-traditional adult students, night-shift workers, single-parent scholars, and second-career learners.',
    schedule: 'Weekly on Wednesdays, 8:45 PM & Sundays, 6:00 PM',
    keyPractices: [
      'Imposter phenomenon deconstruction & academic boundary setting',
      'Asynchronous micro-check-ins via secure peer buddy pairs',
      'Compassionate time re-negotiation & guilt-free rest protocols'
    ],
    clinicalBasis: 'Based on relational-cultural therapy frameworks fostering mutual empathy, reducing isolation, and mitigating non-completion risk.'
  },
  {
    id: 'community-anchor',
    title: 'COMMUNITY ANCHOR',
    category: 'ACCESSIBLE CLINICAL CARE',
    subtitle: 'Sliding-Scale Sanctuary',
    image: '/src/assets/images/pillar_community_circle_1790575180481.jpg',
    description: 'Direct, low-barrier clinical counseling and community mental health navigation with zero institutional bureaucracy and full sliding-scale or free access.',
    targetAudience: 'Uninsured, underinsured adult learners, first-generation immigrant families, and frontline community members.',
    schedule: 'Flexible daytime, evening, and weekend intake appointments',
    keyPractices: [
      'Trauma-informed cognitive reframing & anxiety mitigation',
      'Individual counseling & restorative therapy matching',
      'Direct linkage to adult-student wellness resources and community care'
    ],
    clinicalBasis: 'Utilizes cultural humility frameworks and trauma-informed cognitive behavioral therapy (TF-CBT).'
  },
  {
    id: 'tide-rest-archive',
    title: 'TIDE REST JOURNAL',
    category: 'MICRO-PRACTICES',
    subtitle: 'Restorative Archives',
    image: '/src/assets/images/pillar_rest_journal_1790575192024.jpg',
    description: 'A curated digital and print repository of cognitive reframing worksheets, guided audio meditations, and micro-rest rituals that fit into 10-minute commute windows.',
    targetAudience: 'Adult students with compressed schedules requiring brief, high-yield psychological interventions.',
    schedule: 'On-demand 24/7 access with weekly seasonal prompts',
    keyPractices: [
      'Daily 3-minute evening decompression prompts',
      'Printable academic boundary planning sheets',
      'Binaural soundscapes engineered for deep cognitive recuperation'
    ],
    clinicalBasis: 'Incorporates Acceptance and Commitment Therapy (ACT) values-based micro-actions and mindfulness-based stress reduction (MBSR).'
  }
];

export const OFFERINGS: WellnessOffering[] = [
  {
    id: 'cohort-circles',
    title: 'PEER COHORT CIRCLES',
    shortDesc: 'Structured evening debriefs, shared validation, and resilience pods designed for working adult students.',
    iconName: 'pen',
    fullDesc: 'Small groups of 8-10 adult learners meet weekly with a licensed mental health facilitator to dismantle isolation, process academic fatigue, and exchange practical survival strategies for juggling career and night school.',
    audience: 'Adult learners, distance students, and career-transitioners.',
    outcomes: ['68% reduction in feelings of academic isolation', 'Concrete weekly accountability without punitive pressure', 'Lifelong mutual aid network']
  },
  {
    id: 'burnout-triage',
    title: 'BURNOUT TRIAGE',
    shortDesc: 'Compassionate self-assessment, study load pacing, and academic boundary facilitation.',
    iconName: 'window',
    fullDesc: 'A structured clinical triage helping students differentiate between healthy productive tiredness and dangerous physiological exhaustion. Includes guided support in requesting syllabus extensions and family boundary scripts.',
    audience: 'Students facing chronic deadline dread, insomnia, or emotional numbness.',
    outcomes: ['Personalized energy pacing roadmap', 'Prepared script templates for professor communications', 'Somatic sleep onset routines']
  },
  {
    id: 'somatic-regulation',
    title: 'SOMATIC REGULATION',
    shortDesc: 'Guided nervous-system down-regulation, polyvagal micro-breaks, and acoustic oceanic calm.',
    iconName: 'smartphone',
    fullDesc: 'Physical tension accumulates silently during long screen sessions and high-stakes tests. Our somatic modules teach self-regulation through diaphragmatic breathing, cranial neck releases, and wave-entrained grounding.',
    audience: 'Individuals experiencing physical panic sensations, shallow breathing, and postural stress.',
    outcomes: ['Immediate heart-rate variability improvement', 'Rapid 3-minute emergency calm protocol', 'Reduced tension headaches and muscular fatigue']
  },
  {
    id: 'community-advocacy',
    title: 'COMMUNITY ADVOCACY',
    shortDesc: 'Direct access to counseling support, educational accommodations, and community resource navigation.',
    iconName: 'camera',
    fullDesc: 'Our community advocates assist adult students and community members with personalized counseling coordination, academic accommodations, study pacing, and dedicated advocacy.',
    audience: 'Any community member or adult learner seeking tailored wellness advocacy and counseling support.',
    outcomes: ['Stigma-free counseling navigation', 'Student accommodation support', 'Dedicated guidance and community connection']
  }
];

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: '1',
    quote: 'Working with Ocean Minds was a game changer for my degree. Balancing late-night classes, full-time healthcare shifts, and parenting left me constantly on the brink of collapse. The peer cohort and micro-practices gave me back my peace.',
    author: 'LAURA MITCHELL',
    role: 'NIGHT SCHOOL SCHOLAR & REGISTERED NURSE',
    program: 'Night Scholar Cohort · Class of 2025'
  },
  {
    id: '2',
    quote: 'As a first-generation adult learner returning to college at 38, imposter syndrome was paralyzing. The Coastal Grounding sessions rewired how I face exam anxiety. For the first time in years, I can study without panic.',
    author: 'MARCUS VANCE',
    role: 'FIRST-GEN ENGINEERING ADULT SCHOLAR',
    program: 'Somatic Grounding & Community Anchor'
  },
  {
    id: '3',
    quote: 'This prototype bridges the immense gap between rigid academic institutions and real community mental health. The sliding scale and night-friendly circles allowed four of our local non-profit workers to finish their degrees without burnout.',
    author: 'DR. SOFIA REYES',
    role: 'DIRECTOR OF COMMUNITY ADVOCACY & CIVIC HEALTH',
    program: 'Community Mental Health Partner'
  }
];

export const COHORTS: CohortCircle[] = [
  {
    id: 'c1',
    name: 'Twilight Scholars Circle',
    category: 'evening',
    timing: 'Tuesdays, 8:00 PM – 9:15 PM PST',
    modality: 'Virtual (Zoom)',
    location: 'Interactive Ocean Sanctuary Room',
    facilitator: 'Elena Vance, LCSW',
    facilitatorRole: 'Adult Education Mental Health Specialist',
    spotsLeft: 3,
    description: 'Weekly virtual space for students attending night classes after full-time work shifts. Focus on cognitive decompression, syllabus overwhelm, and restorative rest.'
  },
  {
    id: 'c2',
    name: 'Parenting & Caregiving Learners',
    category: 'caregiver',
    timing: 'Thursdays, 1:00 PM – 2:00 PM PST',
    modality: 'Hybrid',
    location: 'Civic Commons Room 102 & Stream',
    facilitator: 'Dr. Raymond Kim, PsyD',
    facilitatorRole: 'Relational Family Therapist',
    spotsLeft: 5,
    description: 'Support circle addressing the profound friction of caring for children or aging parents while completing collegiate coursework and exams.'
  },
  {
    id: 'c3',
    name: 'First-Gen Navigator Pod',
    category: 'firstgen',
    timing: 'Saturdays, 10:30 AM – 12:00 PM PST',
    modality: 'Virtual (Zoom)',
    location: 'Live Zoom Video Session',
    facilitator: 'Camila Diaz, MSW',
    facilitatorRole: 'First-Gen Student Advocate',
    spotsLeft: 4,
    description: 'Unpacking imposter phenomenon, navigating institutional barriers, and establishing culturally grounded self-worth in academia.'
  },
  {
    id: 'c4',
    name: 'Treatment & Counseling Consultation',
    category: 'clinical',
    timing: 'Daily Mon–Fri, 9:00 AM – 6:00 PM',
    modality: 'In-Person Sanctuary',
    location: 'A Gentle Place Center',
    facilitator: 'Clinical Consultation Team',
    facilitatorRole: 'Licensed Counselors & Care Navigators',
    spotsLeft: 5,
    description: 'Confidential 1-on-1 consultation for personalized treatment planning, individual counseling, and community advocacy.'
  }
];

export const DIAGNOSTIC_QUESTIONS = [
  {
    id: 'q1',
    title: 'Academic & Workload Friction',
    question: 'How often in the past week have you felt overwhelmed by concurrent work, family, and class deadlines?',
    options: [
      { label: 'Rarely / Manageable cadence', score: 1 },
      { label: 'Moderate / Heavy evenings but recovering', score: 2 },
      { label: 'Frequent / Struggling to complete basic reading', score: 3 },
      { label: 'Constant / Severe paralysis and dread', score: 4 }
    ]
  },
  {
    id: 'q2',
    title: 'Somatic Tension & Physical Depletion',
    question: 'Are you experiencing physical signs of strain (jaw clenching, shallow breathing, chronic exhaustion)?',
    options: [
      { label: 'Minimal / Body feels generally at ease', score: 1 },
      { label: 'Mild / Occasional neck/shoulder tightness', score: 2 },
      { label: 'Noticeable / Frequent headaches, fragmented sleep', score: 3 },
      { label: 'Severe / Constant chest tightness, physical collapse', score: 4 }
    ]
  },
  {
    id: 'q3',
    title: 'Belonging & Academic Isolation',
    question: 'Do you feel you have a safe, non-judgmental space or peer group who understands your adult student reality?',
    options: [
      { label: 'Yes / Strong support network in place', score: 1 },
      { label: 'Somewhat / A few friends, but they don’t get adult schooling', score: 2 },
      { label: 'Rarely / Often feel completely alone in this journey', score: 3 },
      { label: 'No / Isolated and questioning whether I belong here', score: 4 }
    ]
  },
  {
    id: 'q4',
    title: 'Rest & Guilt-Free Boundaries',
    question: 'When taking breaks, can you unplug without intense guilt about uncompleted assignments or work tasks?',
    options: [
      { label: 'Yes / Able to savor restorative rest', score: 1 },
      { label: 'Usually / Minor lingering thoughts but can relax', score: 2 },
      { label: 'Difficult / Constantly checking emails and notifications', score: 3 },
      { label: 'Impossible / Pervasive anxiety whenever resting', score: 4 }
    ]
  }
];
