export interface PathwayItem {
  id: string;
  title: string;
  category: string;
  subtitle: string;
  image: string;
  description: string;
  targetAudience: string;
  schedule: string;
  keyPractices: string[];
  clinicalBasis: string;
}

export interface WellnessOffering {
  id: string;
  title: string;
  shortDesc: string;
  iconName: 'pen' | 'window' | 'smartphone' | 'camera';
  fullDesc: string;
  audience: string;
  outcomes: string[];
}

export interface TestimonialItem {
  id: string;
  quote: string;
  author: string;
  role: string;
  program: string;
}

export interface CohortCircle {
  id: string;
  name: string;
  category: 'evening' | 'caregiver' | 'firstgen' | 'clinical' | 'all';
  timing: string;
  modality: 'Virtual (Zoom)' | 'In-Person Sanctuary' | 'Hybrid';
  location: string;
  facilitator: string;
  facilitatorRole: string;
  spotsLeft: number;
  description: string;
}
