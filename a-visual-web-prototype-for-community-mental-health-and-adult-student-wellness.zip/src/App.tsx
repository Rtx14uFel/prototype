import { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import SelectedPathways from './components/SelectedPathways';
import OfferingsSection from './components/OfferingsSection';
import InteractiveWellnessLab from './components/InteractiveWellnessLab';
import CalmingMusicSection from './components/CalmingMusicSection';
import ScheduleSection from './components/ScheduleSection';
import ContactSection from './components/ContactSection';
import PathwayModal from './components/PathwayModal';
import OfferingModal from './components/OfferingModal';
import BreathingModal from './components/BreathingModal';
import GlobalMusicBar from './components/GlobalMusicBar';
import HealioChatModal from './components/HealioChatModal';
import { PathwayItem, WellnessOffering } from './types';
import { CALMING_TRACKS } from './data/musicTracks';
import { Bot } from 'lucide-react';

export default function App() {
  const [selectedPathway, setSelectedPathway] = useState<PathwayItem | null>(null);
  const [selectedOffering, setSelectedOffering] = useState<WellnessOffering | null>(null);
  const [isBreathingModalOpen, setIsBreathingModalOpen] = useState(false);
  const [isHealioOpen, setIsHealioOpen] = useState(false);

  // Global Music State
  const [activeTrackIndex, setActiveTrackIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [autoplayBlocked, setAutoplayBlocked] = useState(false);

  const currentTrack = CALMING_TRACKS[activeTrackIndex] || CALMING_TRACKS[0];

  // Helper to send commands directly into the YouTube IFrame API
  const sendYouTubeCommand = (func: string, args: unknown[] = []) => {
    const iframe = document.getElementById('calming-youtube-player') as HTMLIFrameElement | null;
    if (iframe && iframe.contentWindow) {
      iframe.contentWindow.postMessage(
        JSON.stringify({
          event: 'command',
          func,
          args
        }),
        '*'
      );
    }
  };

  // Two-way synchronization: Listen to real-time events from the YouTube iframe
  useEffect(() => {
    const handleYouTubeMessage = (event: MessageEvent) => {
      try {
        const data = typeof event.data === 'string' ? JSON.parse(event.data) : event.data;
        // YouTube IFrame API sends state in either data.info.playerState or data.event === 'onStateChange'
        const state = data?.info?.playerState ?? (data?.event === 'onStateChange' ? data?.info : undefined);
        if (state === 1) {
          // Playing
          setIsPlaying(true);
        } else if (state === 2) {
          // Paused
          setIsPlaying(false);
        } else if (state === 0) {
          // Track ended -> auto advance to next calming track!
          handleNextTrack();
        }
      } catch {
        // non-JSON message from other extensions or windows
      }
    };

    window.addEventListener('message', handleYouTubeMessage);
    return () => window.removeEventListener('message', handleYouTubeMessage);
  }, []);

  // Immediately activate calming music playback on user interaction
  useEffect(() => {
    const handleFirstInteraction = () => {
      setIsPlaying(true);
      setAutoplayBlocked(false);
      sendYouTubeCommand('playVideo');
      window.removeEventListener('pointerdown', handleFirstInteraction);
      window.removeEventListener('keydown', handleFirstInteraction);
      window.removeEventListener('scroll', handleFirstInteraction);
    };

    window.addEventListener('pointerdown', handleFirstInteraction, { once: true });
    window.addEventListener('keydown', handleFirstInteraction, { once: true });
    window.addEventListener('scroll', handleFirstInteraction, { once: true });

    return () => {
      window.removeEventListener('pointerdown', handleFirstInteraction);
      window.removeEventListener('keydown', handleFirstInteraction);
      window.removeEventListener('scroll', handleFirstInteraction);
    };
  }, []);

  const handleNextTrack = () => {
    const nextIdx = (activeTrackIndex + 1) % CALMING_TRACKS.length;
    setActiveTrackIndex(nextIdx);
    setIsPlaying(true);
    sendYouTubeCommand('loadVideoById', [CALMING_TRACKS[nextIdx].youtubeId]);
  };

  const handlePrevTrack = () => {
    const prevIdx = (activeTrackIndex - 1 + CALMING_TRACKS.length) % CALMING_TRACKS.length;
    setActiveTrackIndex(prevIdx);
    setIsPlaying(true);
    sendYouTubeCommand('loadVideoById', [CALMING_TRACKS[prevIdx].youtubeId]);
  };

  const handleTogglePlay = () => {
    const nextPlaying = !isPlaying;
    setIsPlaying(nextPlaying);
    sendYouTubeCommand(nextPlaying ? 'playVideo' : 'pauseVideo');
  };

  const handleToggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    sendYouTubeCommand(nextMuted ? 'mute' : 'unMute');
  };

  const handleSelectTrack = (index: number) => {
    setActiveTrackIndex(index);
    setIsPlaying(true);
    sendYouTubeCommand('loadVideoById', [CALMING_TRACKS[index].youtubeId]);
  };

  const scrollToContact = () => {
    const el = document.getElementById('contact');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToSchedule = () => {
    const el = document.getElementById('schedule');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToPillars = () => {
    const el = document.getElementById('pillars');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToWellnessLab = () => {
    const el = document.getElementById('wellness-lab');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToMusic = () => {
    const el = document.getElementById('calming-music');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleEnrollPathway = () => {
    scrollToSchedule();
  };

  const handleConnectOffering = () => {
    scrollToSchedule();
  };

  return (
    <div className="min-h-screen bg-[#EBF2F4] text-[#0F373E] font-sans-clean selection:bg-[#B6D6D9] selection:text-[#0A262C] flex flex-col justify-between pb-16">
      {/* 1. Header matching reference top bar */}
      <Header
        onOpenIntake={scrollToSchedule}
        onOpenBreathing={() => setIsBreathingModalOpen(true)}
        onOpenHealio={() => setIsHealioOpen(true)}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* 2. Hero Section with display serif title, sunset beach background, and active music indicator */}
        <Hero
          onOpenBreathing={() => setIsBreathingModalOpen(true)}
          onExploreClick={scrollToPillars}
          onMusicClick={scrollToMusic}
          onHealioClick={() => setIsHealioOpen(true)}
          currentTrack={currentTrack}
          isPlaying={isPlaying}
        />

        {/* 3. Selected Work / Pillars Section ("Crafted with Purpose") */}
        <SelectedPathways
          onSelectPathway={(item) => setSelectedPathway(item)}
          onViewAllClick={scrollToWellnessLab}
        />

        {/* 4. What We Do / Services Section ("Care that Moves with Meaning") */}
        <OfferingsSection
          onSelectOffering={(item) => setSelectedOffering(item)}
          onConsultationClick={scrollToSchedule}
        />

        {/* 5. Interactive Adult-Student Wellness Lab & Micro-Tools */}
        <InteractiveWellnessLab />

        {/* 6. Calming Music Sanctuary Feature with All 9 Tracks */}
        <CalmingMusicSection
          activeTrackIndex={activeTrackIndex}
          onSelectTrack={handleSelectTrack}
          isPlaying={isPlaying}
          isMuted={isMuted}
          onTogglePlay={handleTogglePlay}
        />

        {/* 7. Schedule for Treatment, Counseling, & Community Advocacy */}
        <ScheduleSection />

        {/* 8. Contact & Community Intake ("Let's Foster Healing Together") */}
        <ContactSection />
      </main>

      {/* Floating Healio AI Counselor Trigger Button with Portrait */}
      <button
        onClick={() => setIsHealioOpen(true)}
        className="fixed bottom-20 sm:bottom-4 left-4 sm:left-6 z-40 bg-[#0C323A]/95 hover:bg-[#07242A] text-white text-xs font-semibold py-2 px-3.5 rounded-full shadow-2xl border border-white/20 flex items-center gap-3 cursor-pointer transition-transform hover:scale-105 backdrop-blur-md group"
        title="Talk to Healio AI Counselor"
      >
        <div className="relative shrink-0">
          <div className="w-8 h-8 rounded-full overflow-hidden border-1.5 border-[#8CD7E5] shadow-xs">
            <img
              src="/src/assets/images/healio_counselor_portrait_1790580704967.jpg"
              alt="Healio Counselor"
              className="w-full h-full object-cover object-center"
            />
          </div>
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 block absolute -bottom-0.5 -right-0.5 border-2 border-[#0C323A]"></span>
        </div>
        <div className="text-left">
          <div className="flex items-center gap-1.5">
            <span className="font-serif-display text-sm font-medium tracking-wide">Healio</span>
            <span className="text-[9px] uppercase font-bold text-[#8CD7E5] bg-[#174F5A] px-1.5 py-0.2 rounded-xs">Counselor</span>
          </div>
          <p className="text-[10px] text-white/70 font-light hidden sm:block">Decision & Comfort Guide</p>
        </div>
      </button>

      {/* Persistent Global Floating Music Player Bar */}
      <GlobalMusicBar
        currentTrack={currentTrack}
        isPlaying={isPlaying}
        isMuted={isMuted}
        autoplayBlocked={autoplayBlocked}
        onTogglePlay={handleTogglePlay}
        onToggleMute={handleToggleMute}
        onNext={handleNextTrack}
        onPrev={handlePrevTrack}
        onOpenSanctuary={scrollToMusic}
        onUnblockAutoplay={() => {
          setIsPlaying(true);
          setAutoplayBlocked(false);
          sendYouTubeCommand('playVideo');
        }}
      />

      {/* Healio AI Counselor Modal */}
      <HealioChatModal
        isOpen={isHealioOpen}
        onClose={() => setIsHealioOpen(false)}
      />

      {/* Modals */}
      <PathwayModal
        pathway={selectedPathway}
        onClose={() => setSelectedPathway(null)}
        onEnroll={handleEnrollPathway}
      />

      <OfferingModal
        offering={selectedOffering}
        onClose={() => setSelectedOffering(null)}
        onConnect={handleConnectOffering}
      />

      <BreathingModal
        isOpen={isBreathingModalOpen}
        onClose={() => setIsBreathingModalOpen(false)}
      />
    </div>
  );
}
